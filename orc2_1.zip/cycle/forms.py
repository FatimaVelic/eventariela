# -*- coding: utf-8 -*-
"""
Created on Thu Sep  9 13:45:15 2021

@author: DEBIEVEL
"""
from django import forms
from .models import Calculation
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm


class NewUserForm(UserCreationForm):
    """
    Used for registration of new users. Since UserCreationForm is Django auth form, 
    built in validation mechanisms are applied to it. 
    """
    
    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password1','password2',]       


class NewCalculationForm(forms.ModelForm):
    """
    Used for creation of new Calculation instance. Double validation mechanism is applied on this form.
    First the default validation mechanism provided Django ModelForm, than custom validators are applied. 
    If validation = true, index view persue with calculation and create a new instance in Calculations model. 
    If validation = false, user is prompt wih error message and clean form 
    """
    
    def clean(self): #razlika tsrcin > tsrcout: 200, razlika tsinkin < tsinkout 10-30
        cleaned_data = super(NewCalculationForm, self).clean()
        Tsinkin = self.cleaned_data.get('Tsinkin')
        Tsinkout = self.cleaned_data.get('Tsinkout')
        Tsrcin = self.cleaned_data.get('Tsrcin')
        Tsrcout = self.cleaned_data.get('Tsrcout')
        Qsrc = self.cleaned_data.get('Qsrc')
        if Qsrc < 150:
            raise forms.ValidationError("Heating power must be in range of 150-3000 KW")
        if Qsrc > 3000:
            raise forms.ValidationError("Heating power must be in range of 150-3000 KW")
        if Tsrcin <= Tsrcout:
             raise forms.ValidationError("Source outlet temperature has to be lower than inlet temperature.")
        if Tsinkin >= Tsinkout:
             raise forms.ValidationError("Sink outlet temperature has to be higher than inlet temperature.")
        if abs(Tsinkout-Tsinkin) > 30:
             raise forms.ValidationError("Sink outlet temperature has to be from 10 to 30 degrees higher than inlet temperature.")
        if abs(Tsinkout-Tsinkin) < 10:
             raise forms.ValidationError("Sink outlet temperature has to be from 10 to 30 degrees higher than inlet temperature.")
        if abs(Tsrcin-Tsrcout) < 200:
             raise forms.ValidationError("Source outlet temperature has to be at least 200 degrees lower than inlet temperature..")
        return cleaned_data

    class Meta:
        model = Calculation
        fields = ['Tsrcin', 'Tsrcout', 'Qsrc','Tsinkin','Tsinkout',]
   