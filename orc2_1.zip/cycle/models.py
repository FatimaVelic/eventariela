from django.db import models
from django.contrib.auth.models import User  # Required to assign User as a borrower
from django.urls import reverse # Used to generate URLs by reversing the URL patterns
from django.utils.text import slugify #Used for generating slugs
import uuid #Universaly unique identifier

""" 
Model represents a table in database. When executed, following code will be translated into SQL statements and 
a table with corresponding fields and relations will be creaed in a database. 
After every change made to model or its fields, it is necessary to execute:
    - python manage.py makemigrations - translates changes from Python code to SQL staements 
    - python manage.py migrate - applies changes to actual table in databse. 
Migrations records are stored in /project/app/migrations/ folder
"""
class Calculation (models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False) #required property for each table
    userid = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=False) #used to connect two tables in database
    
    tsrcin_choices = ()
    for i in range(350,501,5):
        tsrcin_choices = tsrcin_choices + ((i,str(i)),)
    Tsrcin = models.FloatField(verbose_name = "Inlet temperature of the source", choices = tsrcin_choices, null = True, blank = False)
    
    tsrcout_choices = ()
    for i in range(120,151):
        tsrcout_choices = tsrcout_choices + ((i,str(i)),)
    Tsrcout = models.FloatField(verbose_name = "Outlet temperature of the source",choices = tsrcout_choices, null=True, blank = False)
    
    tsinkin_choices = ()
    for i in range(0,81):
        tsinkin_choices = tsinkin_choices + ((i,str(i)),)
    Tsinkin = models.FloatField(verbose_name = "Inlet temperature for the sink", choices = tsinkin_choices, null = True, blank = False)

    tsinkout_choices = ()
    for i in range(30,91):
        tsinkout_choices = tsinkout_choices + ((i,str(i)),)
    Tsinkout = models.FloatField(verbose_name = "Outlet temperature for the sink", choices = tsinkout_choices, null = True, blank = False)

    Qsrc = models.FloatField(verbose_name = "Heating power", null=True, blank = False)
    Pel = models.FloatField(max_length = 10, verbose_name ="Electricity produced (gross)", null=True, blank = True)
    thermaleff = models.FloatField(max_length = 10, verbose_name ="Thermal efficiency", null=True, blank = True)
    result = models.FloatField(max_length = 10, verbose_name ="Electricity produced (nett)", null=True, blank = True)
    result_ts = models.ImageField(verbose_name = "TS Diagram", blank=True, null=True, upload_to='photos/%Y/%m/%d/')
    result_tq = models.ImageField(verbose_name = "TQ Diagram", blank=True, null=True, upload_to='photos/%Y/%m/%d/')
    time_calculated = models.DateTimeField(null =True, blank = True )
    slug = models.SlugField(null=True, unique=True) #used for generating a valid URL from already obtained data
    
    class Meta:
        ordering = ["-time_calculated", "-userid"] #ordering of data in lists

    def __str__(self):
        """String for representing the Model object."""
        return 'Calculation on {0} by {1}'.format(self.time_calculated, self.userid)
    
    def get_absolute_url(self):
        """Returns the url to access a detail record for this model."""
        return reverse('calculation-detail', kwargs={'slug': self.slug})

    def save(self, *args, **kwargs):
        """Generates slug field for each specific object in a model"""
        self.slug = slugify(self.id)
        super(Calculation, self).save(*args, **kwargs)
    
        
        
        