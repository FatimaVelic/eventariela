# -*- coding: utf-8 -*-
"""
Created on Thu Sep  9 10:12:26 2021

@author: DEBIEVEL
"""
from django.urls import path
from django.conf import settings
from django.conf.urls import url
from django.conf.urls.static import static
from django.views.generic import TemplateView

from . import views
from .filters import CalculationFilter
from django_filters.views import FilterView

"""
Application url mapper - responsible for mapping links to view classes and functions. 
Handles link requests to templates without views, points to and connects serving static and media files. 
 
"""


urlpatterns = [
    path('', views.index, name='index'),
]

urlpatterns += [
    path('calculations/', views.CalculationListView.as_view(), name='calculations'),
    path('calculation/<slug:slug>', views.CalculationDetailView.as_view(), name='calculation-detail'),
    path('users/', views.UserListView.as_view(), name='users'),
    path('user/<int:pk>', views.UserDetailView.as_view(), name='user-detail'),
    path('user/<int:pk>/delete/', views.UserDeleteView.as_view(), name='user-delete'),
    path('registerc/', views.register_client, name="register-client"),
    path('registera/', views.register_administrator, name="register-administrator"),
    path('mycalculations/', views.CalculationsByUserListView.as_view(), name='mycalcs'),
    path('graphs/', views.generate_graphs, name='graphs'),
    url(r'generate-pdf/$', views.GenerateCalcDetailPdf.as_view(), name='generate-pdf'),
    url(r'^search/$', FilterView.as_view(filterset_class=CalculationFilter,
        template_name='cycle/calculation_list.html'), name='search'),
    url('contact/', TemplateView.as_view(template_name="contact.html"), name='contact'),
]

urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)