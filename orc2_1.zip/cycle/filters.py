# -*- coding: utf-8 -*-
"""
Created on Fri Sep 24 10:53:20 2021

@author: DEBIEVEL
"""

import django_filters
from .models import Calculation

class CalculationFilter(django_filters.FilterSet):
    """ 
    Implementation of django filter property. This filter is confiured to filter Calculation data 
    based on phrase contained in one of fields specified. 
    """
    class Meta:
        model = Calculation
        fields = {
                  "Tsrcin": ["icontains"], 
                  "Tsrcout" : ["icontains"],
                  "Tsinkin" : ["icontains"],
                  "Tsinkout" : ["icontains"],
                  "Qsrc" : ["icontains"],
                  "Pel" : ["icontains"],
                  "result" : ["icontains"],
                  "thermaleff" : ["icontains"],
                 }
    