# -*- coding: utf-8 -*-
"""
Created on Fri Sep 10 09:51:00 2021

@author: DEBIEVEL
"""
from django.test import TestCase, RequestFactory
from django.contrib.auth.models import User, AnonymousUser
from cycle.models import Calculation 
import cycle.views as views
from django.urls import reverse
import tempfile 


class ViewRequestFactoryTestMixin(object):
    """Mixin with shortcuts for view tests."""
    longMessage = True  # More verbose messages
    view_class = None
   
    def get_response(self, method):
        factory = RequestFactory()
        req = getattr(factory, method)('/')
        req.user = AnonymousUser()
        return self.view_class.as_view()(req, *[], **{})
   
    def is_callable(self):
        resp = self.get_response('get')
        self.assertEqual(resp.status_code, 200)


class CalculationListViewTest(ViewRequestFactoryTestMixin, TestCase):
    @classmethod
    def setUp(cls):
        # Create 13 authors for pagination tests
        number_of_calculations = 13

        for calc_id in range(number_of_calculations):
            Calculation.objects.create(Tsrcin='230', Tsrcout='350', Qsrc='580',result='320',)
    
    def test_view_url_exists_at_desired_location(self):
        response = self.client.get('/cycle/calculations/')
        self.assertEqual(response.status_code, 200)
    
    def test_view_url_accessible_by_name(self):
        response = self.client.get(reverse('calculations'))
        self.assertEqual(response.status_code, 200)
    
    def test_view_uses_correct_template(self):
        response = self.client.get(reverse('calculations'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'cycle/calculation_list.html')
    
    def test_pagination_is_ten(self):
        response = self.client.get(reverse('calculations'))
        self.assertEqual(response.status_code, 200)
        self.assertTrue('is_paginated' in response.context)
        self.assertTrue(response.context['is_paginated'] == True)
        self.assertEqual(len(response.context['calculation_list']), 20)


class CalculationsByUserListViewTest(ViewRequestFactoryTestMixin, TestCase):
    
    def setUp(self):
        # Create two users
        test_user1 = User.objects.create_user(username='testuser1', password='1X<ISRUkw+tuK')
        test_user2 = User.objects.create_user(username='testuser2', password='2HJ1vRV0Z&3iD')

        test_user1.save()
        test_user2.save()
        
        img = tempfile.NamedTemporaryFile(suffix=".jpg").name
        number_of_calculations = 10
        
        for calc_id in range(number_of_calculations):
            Calculation.objects.create(Tsrcin='230', Tsrcout='350', Qsrc='580',result='320', \
                                       result_ts = img, result_tq = img,)
    
    def test_redirect_if_not_logged_in(self):
        response = self.client.get(reverse('mycalcs'))
        self.assertRedirects(response, '/accounts/login/?next=/cycle/mycalculations/') 
            
    def test_logged_in_uses_correct_template(self):
        login = self.client.login(username='testuser1', password='1X<ISRUkw+tuK')
        response = self.client.get(reverse('mycalcs'))

        # Check our user is logged in
        self.assertEqual(str(response.context['user']), 'testuser1')
        # Check that we got a response "success"
        self.assertEqual(response.status_code, 200)
        # Check we used correct template
        self.assertTemplateUsed(response,'calculationUser.html', 'base_generic.html')     
    
    def test_calculations_in_list(self):    
        login = self.client.login(username='testuser1', password='1X<ISRUkw+tuK')
        response = self.client.get(reverse('mycalcs'))

        # Check our user is logged in
        self.assertEqual(str(response.context['user']), 'testuser1')
        # Check that we got a response "success"
        self.assertEqual(response.status_code, 200)

        # Check that initially we don't have any calculations in list
        self.assertTrue('calculation_list' in response.context)
        self.assertEqual(len(response.context['calculation_list']), 0)

        # Now assign some calculations to testuser1
        calculation = Calculation.objects.all()[:10]

        for calc in calculation:
            User.username = 'testuser1'
            calc.save()

        # Check that now we have some calculations in the list
        response = self.client.get(reverse('mycalcs'))
        # Check our user is logged in
        self.assertEqual(str(response.context['user']), 'testuser1')
        # Check that we got a response "success"
        self.assertEqual(response.status_code, 200)

        self.assertTrue('calculation_list' in response.context)

        # Confirm all calculations belong to testuser1
        for calc in response.context['calculation_list']:
            self.assertEqual(response.context['user'], calc.userid)

class UserListViewTest(ViewRequestFactoryTestMixin, TestCase):
    
    view_class = views.UserListView
    def test_get(self):
        self.is_callable()
    
    """self.is_callable() mutually excludes test_view_url_exists_at_desired_location
       and test_view_url_accessible_by_name """

    def test_view_uses_correct_template(self):
        response = self.client.get(reverse('users'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'auth/user_list.html')

    

""" 
Test results 
-------------

Tests run on 11:29, 10.09.2021.
Summary: 10 tests run
Errors: 1 - SyntaxError: keyword can't be an expression
Status: FAILED
Actions to be done: modify code to remove syntax error

-----------------------------------
Tests run on 11:38, 10.09.2021.

Summary: 16 tests run, 1 failures
Errors: 2 
    1. django.urls.exceptions.NoReverseMatch: Reverse for 'calculation' not found.
    2. ValueError: Cannot assign "'testuser1'": "Calculation.userid" must be a "User" instance.
Status: FAILED

def test_logged_in_uses_correct_template(self):
Expected: pass
Result: fail

Actions to be done: resolve both errors by adjusting patterns 

-----------------------------------
Tests run on 11:49, 10.09.2021.

Summary: 16 tests run, 1 failures
Errors: 1 - ValueError: Cannot assign "'testuser1'": "Calculation.userid" must be a "User" instance.
Status: FAILED
Actions to be done: Attempt fixing url configuration with templates

---------------------------------
Tests run on 11:53, 10.09.2021.

Summary: 16 tests run, 1 failures
Errors: 1 - AttributeError: 'Calculation' object has no attribute 'user'
Status: FAILED
Actions to be done: Attempt fixing url configuration with templates

---------------------------------
Tests run on 12:59, 10.09.2021.

Summary: 16 tests run, 1 failures
Errors:
Status: FAILED
Actions to be done: Attempt fixing url configuration with templates

---------------------------------
Tests run on 10:43, 13.09.2021.

Summary: 16 tests run, 0 failures
Errors: 
Status: OK
Actions to be done: Write more tests

---------------------------------
Tests run on 08:34, 16.09.2021.

Summary: 17 tests run, 0 failures
Errors: 
Status: OK
Actions to be done: Write more tests

---------------------------------
Tests run on 10:37, 16.09.2021.

Summary: 18 tests run, 0 failures
Errors: 
Status: OK
Actions to be done: 

---------------------------------

"""        
            
            
            
            
            
            
            
            