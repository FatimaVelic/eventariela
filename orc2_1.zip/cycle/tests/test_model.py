# -*- coding: utf-8 -*-
"""
Created on Fri Sep 10 08:32:19 2021

@author: DEBIEVEL
"""

from django.test import TestCase
from cycle.models import Calculation 
import tempfile

class CycleModelTest(TestCase):
    @classmethod
    
    def setUpTestData(cls):
        # Non-modified objects used by all test methods
        Calculation.objects.create(Tsrcin='230', Tsrcout='350', Qsrc='580', \
                                   result='320')
    
    def test_tscrin_label(self):
       calculation = Calculation.objects.get(id=1)
       field_label = calculation._meta.get_field('Tsrcin').verbose_name
       self.assertEqual(field_label, 'Inlet temperature of the source')
    
    def test_tscrout_label(self):
       calculation = Calculation.objects.get(id=1)
       field_label = calculation._meta.get_field('Tsrcout').verbose_name
       self.assertEqual(field_label, 'Outlet temperature of the source')
    
    def test_qsrc_label(self):
       calculation = Calculation.objects.get(id=1)
       field_label = calculation._meta.get_field('Qsrc').verbose_name
       self.assertEqual(field_label, 'Source massflow')
    
    def test_result_label(self):
       calculation = Calculation.objects.get(id=1)
       field_label = calculation._meta.get_field('result').verbose_name
       self.assertEqual(field_label, 'result')
    
    def test_resultts_label(self):
       calculation = Calculation.objects.get(id=1)
       field_label = calculation._meta.get_field('result_ts').verbose_name
       self.assertEqual(field_label, 'TS Diagram')
       
    def test_resulttq_label(self):
       calculation = Calculation.objects.get(id=1)
       field_label = calculation._meta.get_field('result_tq').verbose_name
       self.assertEqual(field_label, 'TQ Diagram')
    
    def test_add_photo(self):
        newPhoto = Calculation()
        newPhoto.image = tempfile.NamedTemporaryFile(suffix=".jpg").name
        newPhoto.save()
        self.assertEqual(Calculation.objects.count(), 2)

    def test_result_max_length(self):
        result = Calculation.objects.get(id=1)
        max_length = result._meta.get_field('result').max_length
        self.assertEqual(max_length, 10)
    
    def test_get_absolute_url(self):
        calculation = Calculation.objects.get(id=1)
        # This will also fail if the urlconf is not defined.
        self.assertEqual(calculation.get_absolute_url(), '/cycle/calculation/1')

""" 
Test results 
-------------

Tests run on 9:15, 10.09.2021.
Summary: 8 tests run, 4 failures

Errors: 1 - Integrity Error: Not Null constraint failed for Tsrcsin
Status: Failed

def test_tscrin_label(self):
Expected: fail
Result: fail

def test_tscrout_label(self):
Expected: fail
Result: fail

def test_qsrc_label(self):
Expected: fail
Result: fail

def test_result_label(self):
Expected: pass
Result: fail

def test_resultts_label(self):
Expected: pass
Result: pass

def test_resulttq_label(self):
Expected: pass
Result: pass

def test_add_photo(self):
Expected: fail
Result: pass

def test_get_absolute_url(self):
Expected: pass
Result: pass

Actions to be done: apply changes to Tsrcin in models

-----------------------------------
Tests run on 9:23, 10.09.2021.

Summary: 8 tests run, 0 failures
Errors: 1 - Integrity Error: Not Null constraint failed for Tsrcout
Status: Failed
Actions to be done: apply changes to Tsrcout in models

---------------------------------
Tests run on 9:27, 10.09.2021.

Summary: 8 tests run, 0 failures
Errors: 1 - Integrity Error: Not Null constraint failed for result
Status: Failed
Actions to be done: apply changes to result in models, test for result.max_lenght

---------------------------------
Tests run on 9:32, 10.09.2021.

Summary: 9 tests run, 1 failures
Errors: None
Status: Failed

def test_result_max_lenght(self):
Expected: fail
Result: fail

Actions to be done: None
---------------------------------
Tests run on 9:33, 10.09.2021.

Summary: 9 tests run, 0 failures
Errors: None
Status: OK
Actions to be done: write more tests

"""