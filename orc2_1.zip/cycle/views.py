from django.shortcuts import render, redirect
from django.views import generic
from django.urls import reverse, reverse_lazy
from django.http import HttpResponse, HttpResponseRedirect 
from django.contrib import messages
from django.utils.safestring import mark_safe #used for formating stings using HTML tags and passing them to template

import pandas as pd
import plotly.express as px #for graphing dynamic graphs
from plotly.offline import plot #for rendering dynamically graphed figures 


import os
from io import StringIO
from xhtml2pdf import pisa 
from django.template.loader import get_template 
from puppeteer_pdf.views import PDFTemplateView #Python wrapper for puppeteer.js 

from django.core.files import File as DjangoFile
from datetime import datetime
from django.db.models import Q #Chaining queries for complex filtering 

from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin #Set permissions and restrictions on views
from django.contrib.auth.models import Group, User

from .models import Calculation 
from .forms import NewUserForm, NewCalculationForm
from modules.calculation import cycle_simulation


def index(request):
    """
    Homepage 
    Function validates form, performs calculation thatn stores parameters into database
    Form is passed to user as a POST request. After data is filled in, form is returned 
    back to server where default and custom validators are applied. 
    If validation == true, input values are sent to internal script for calculation. 
    Together with returned variables frominternal script, a database entery is created where form input 
    and calculation output parameters are stored to corresponding fields in database. User is presented with
    sucess message and redirect to new page where details of performed calculation are displayed. 
    If validation == false, user is presented with cleared form and an error message listing errors that might have
    had caused validation to fail. User is asked to fill in the form again.
    
    """
    if request.method == 'POST':
        form = NewCalculationForm(request.POST or None)
        if form.is_valid(): #cleans data and applies default and custom form validators
            Tsrcin = form.cleaned_data.get("Tsrcin")
            Tsrcout = form.cleaned_data.get("Tsrcout")
            Qsrc = form.cleaned_data.get("Qsrc")
            Tsinkin = form.cleaned_data.get("Tsinkin")
            Tsinkout = form.cleaned_data.get("Tsinkout")
            [Pnet, Pel, thermaleff, savepath] = cycle_simulation(Tsrcin, Tsrcout, Qsrc, Tsinkin, Tsinkout)
            """
                Internal script plots TS and TQ diagams of the cycle and stores them as images. 
                Images are retrieved by name and path provided by internal script and converted into special 
                type of file in order to be saved to database and easily rendered in templates. 
            """
            file1 = DjangoFile(open(os.path.join(savepath, "TSDiagrammORCCycle.png"), mode='rb'),name='PNG')  
            file2 = DjangoFile(open(os.path.join(savepath, "TQDiagrammORCCycle.png"), mode='rb'),name='PNG')
            instance = Calculation.objects.create(userid = request.user,Tsrcin = Tsrcin, Tsrcout = Tsrcout,\
                                           Qsrc = Qsrc, Tsinkin = Tsinkin, Tsinkout = Tsinkout, Pel = Pel,\
                                           time_calculated = datetime.today(), result = Pnet,\
                                           thermaleff = thermaleff, result_ts = file1, result_tq = file2)
            
            messages.success(request, mark_safe( "<strong>Calculation perfomed sucessfully!</strong>" ))
            return HttpResponseRedirect(reverse('calculation-detail', kwargs={'slug': instance.slug}))
        else:
            messages.error(request, mark_safe("<strong>Your calculation could not be completed due to values you entered are incorect.</strong> <br><br> Please try again and make sure that:<br> \
                                              - Source outlet temperature has to be lower than inlet temperature<br> \
                                              - Sink outlet temperature has to be higher than inlet temperature.<br> \
                                              - Heating power must be in range of 150-3000 KW <br> \
                                              - Sink outlet temperature has to be from 10 to 30 degrees higher than inlet temperature.<br>\
                                              - Source outlet temperature has to be at least 200 degrees lower than inlet temperature. "))
            form = NewCalculationForm()
    else:
        form = NewCalculationForm()
        
    return render(request, "index.html", context={"NewCalculationForm":form})


#List views 
class CalculationListView(LoginRequiredMixin, generic.ListView):
    """
    Class based list view generated by Django's internal mechanisms. It lists all calculations currently stored in database.
    This view requires user to be logged in. Restriction logic is applied in template. 
    """
    
    model = Calculation
    paginate_by = 20
    
    def get_queryset(self):
        """ 
        Override of default function. Function is implemeted to display data based on searched phrase. 
        Logic:
        The phrase is retrieved from template by GET request. Explicit casting is performed to establish the type of input phrase. 
        If phrase is int or float, queryset will be filtered by first match containing the phrase found in numeric data stored in table.
        If phrase is a string, queryset will be filtered by first match containing the phrase found in usernames of the users who perfomed calculation.
        In case where phrase does not match to any of the fields in queryset, appropriate message is displayed to user. 
        In case where phrase is an empty string, all objects saved in database under Calculation table are listed. 
        """
        
        query = self.request.GET.get('q')
        if query is not None:
            try:
                if float(query):
                    query = float(query)
                else:
                    query = int(query)
                    
                object_list = self.model.objects.filter(
                                                    Q(Tsrcin__icontains=(query)) | Q(Tsrcout__icontains=(query)) |
                                                    Q(Tsinkin__icontains=(query)) | Q(Tsinkout__icontains=(query)) |
                                                    Q(Qsrc__icontains=(query)) | Q(result__icontains=(query)) |
                                                    Q(Pel__icontains=(query)) | Q(thermaleff__icontains=(query))
                                                    )
            except ValueError:
                pass
                object_list = self.model.objects.filter(userid__username__icontains=query)
        else:
            object_list = self.model.objects.all()
        return object_list

class CalculationsByUserListView(LoginRequiredMixin, generic.ListView):
    """
    Class based list view generated by Django's internal mechanisms. It lists all calculations currently stored in database.
    This view requires user to be logged in. Restriction logic is applied in template. 
    """
    
    model = Calculation
    paginate_by = 20
    template_name = 'calculationUser.html'
    
    def get_queryset(self):
        """ 
        Override of default function. Function is implemeted to display data based on searched phrase. 
        Logic:
        The phrase is retrieved from template by GET request. Explicit casting is performed to establish the type of input phrase. 
        If phrase is int or float, queryset will be filtered by first match containing the phrase found in numeric data stored in table.
        If phrase is a string, queryset will be filtered by first match containing the phrase found in usernames of the users who perfomed calculation.
        In case where phrase does not match to any of the fields in queryset, appropriate message is displayed to user. 
        In case where phrase is an empty string, all objects saved in database under Calculation table are listed. 
        """
        
        object_list = self.model.objects.filter(userid = self.request.user)
        query = self.request.GET.get('q')
        if query is not None:
            try:
                if float(query):
                    query = float(query)
                else:
                    query = int(query)
                    
                object_list = object_list.filter(
                                                Q(Tsrcin__icontains=(query)) | Q(Tsrcout__icontains=(query)) |
                                                Q(Tsinkin__icontains=(query)) | Q(Tsinkout__icontains=(query)) |
                                                Q(Qsrc__icontains=(query)) | Q(result__icontains=(query)) |
                                                Q(Pel__icontains=(query))
                                                )
            except ValueError:
                pass
                object_list = self.model.objects.filter(userid = self.request.user)
        else:
            object_list = self.model.objects.filter(userid = self.request.user)
        return object_list
    
class UserListView(LoginRequiredMixin, generic.ListView):
    """
    Class based list view generated by Django's internal mechanisms. It lists all users currently stored in database.
    This view requires user to be logged in. Restriction logic is applied in template. 
    """
    
    model = User
    paginate_by = 20
    
    def get_queryset(self):
        """ 
        Override of default function. Function is implemeted to display data based on searched phrase. 
        Logic:
        The phrase is retrieved from template by GET request. Explicit casting is performed to establish the type of input phrase. 
        Queryset will be filtered by first match containing the phrase found in usernames of the users currently stored in database.
        In case where phrase does not match to any of the fields in queryset, appropriate message is displayed to user. 
        In case where phrase is an empty string, all objects saved in database under User table are listed. 
        """
        
        query = self.request.GET.get('q')
        if query is not None:
            try:
                query = int(query)
                object_list = self.model.objects.filter(username__icontains=query)
            except ValueError:
                pass
                object_list = self.model.objects.filter(username__icontains=query)
        else:
            object_list = self.model.objects.all().exclude(is_superuser=True)
        return object_list


#Detail and deletion views
class CalculationDetailView(UserPassesTestMixin, LoginRequiredMixin, generic.DetailView):
    """
    Class based detailed view generated by Django's internal mechanisms. It displays details of selected instance of Calculation currently stored in database.
    This view requires user to be logged in and it is written in such way that users cannot access details of calculations performed by
    other users unless they have staff status.  
    """
    
    model = Calculation
    
    def test_func(self):
        """ 
        Test function required by UserPassesTestMixin. Implementation is such that it tests for authentication
        and redirects to Login page if user is not logged in or displays 404 (Not found) page if user doesn't have
        staff status and requests details of calculation perfomed by other user. 
        """
        return self.request.user.is_authenticated

    def get_queryset(self):
        """ 
        Override of default function. 
        Function is implemeted to only display data of user who is currently logged in.
        Users with staff status will be able to access details of every calculation.
        """
        qs = super().get_queryset()
        if not self.request.user.is_staff:                
          qs = qs.filter(userid=self.request.user.pk)
        return qs
    
class UserDetailView(LoginRequiredMixin, generic.DetailView):
    """
    Class based detail view generated by Django's internal mechanisms.It displays details of selected instance of User currently stored in database.
    This view requires user to be logged in. Restriction logic is applied in template. 
    """
    
    model = User
    template_name = 'auth/user_detail.html'


class UserDeleteView (LoginRequiredMixin, generic.DeleteView):
    """
    Class based delete view generated by Django's internal mechanisms. It handles the mechanism of removing user instance from User table in database. 
    This view requires user to be logged in. Restriction logic is applied in template. 
    """
    model = User
    success_url = reverse_lazy('users')  
    success_message = "User successfully deleted."

    def delete(self, request, *args, **kwargs):
        messages.success(self.request, self.success_message)
        return super(UserDeleteView, self).delete(request, *args, **kwargs)      

def generate_graphs(request):
    """
    Function for generating visual representation of data. It responds to GET request sent triggered by a button and
    generates graphs from the dataframe dynamically created from Calculation table queryset. 
    """
    
    pd.set_option("display.precision", 2) #Affects value precison displayed in template. Default: 6 
    qs = pd.DataFrame(list(Calculation.objects.all().values()))

    fig = px.scatter(qs, x="Tsrcin", y="Tsrcout", title="Source temperatures",
                     labels={"Tsrcin": "Source inlet temperature", "Tsrcout": "Source outlet temperature"},
                     color_continuous_scale="ice", color="Tsrcin", template="plotly_white")
    plot_div1 = plot(fig, output_type='div', include_plotlyjs=False) 
    #After graph is plotted in a figure, it will be ouptuted in template as div element. To increase the speed of rendering, 
    #include_plotlyjs property is set to false and plotly.js is loaded externally in template.
    
    fig = px.scatter(qs, x="Tsinkin", y="Tsinkout", title="Sink temperatures", 
                     labels={"Tsinkin": "Sink inlet temperature", "Tsinkout": "Sink outlet temperature"},
                     color_continuous_scale="ice", color="Tsinkin", template="plotly_white")
    plot_div2 = plot(fig, output_type='div', include_plotlyjs=False)
    
    fig = px.violin(qs, x="Pel", title="Gross energy production",
                    labels={"Pel": "Gross"},
                    color_discrete_sequence=['#325A9B'], template="plotly_white")
    plot_div3 = plot(fig, output_type='div', include_plotlyjs=False)
    
    fig = px.violin(qs, x="result", title="Nett energy production",
                    labels={"result": "Nett"},
                    color_discrete_sequence=['darkgreen'], template="plotly_white")
    plot_div4 = plot(fig, output_type='div', include_plotlyjs=False)
    
    fig = px.histogram(qs, x="Qsrc", title="Heating power",
                       labels={"Qsrc":"Heating power in KW"},
                       color_discrete_sequence=['darkred'], template="plotly_white")
    fig.update_traces(xbins=dict(start=100, end=3000, size=80))
    plot_div5 = plot(fig, output_type='div', include_plotlyjs=False)
        
    fig = px.histogram(qs, x="thermaleff", title="Thermal efficiency",
                       labels={"thermaleff":"Thermal efficiency %"},
                       color_discrete_sequence=['purple'], template="plotly_white")
    fig.update_traces(xbins=dict(size=1))
    plot_div6 = plot(fig, output_type='div', include_plotlyjs=False)
   
    context = {
        'plot_div1': plot_div1,
        'plot_div2': plot_div2,
        'plot_div3': plot_div3,
        'plot_div4': plot_div4,
        'plot_div5': plot_div5,
        'plot_div6': plot_div6
    }
    
    return render(request, 'charts.html', context)
    
def generate_calc_detail_pdf(request):
    """ 
    Primary mechanism: function generates PDF from html template. It is triggered by a GET request passed on a button click.
    Reises ConnectionRefusedError 
    TODO - Needs testing in independent environment
    """
    
    calc_list = Calculation.objects.filter(userid = request.user)
    template = get_template("cycle/calculation_detail.html") 
    context = {'calc': calc_list} 
    html = template.render(context) 
    result = StringIO() 
    pdf = pisa.pisaDocument(StringIO(html), dest=result) 
    if not pdf.err: 
        return HttpResponse(result.getvalue(), content_type='application/pdf') 
    else: 
        return HttpResponse('Errors')

class GenerateCalcDetailPdf(PDFTemplateView):
    """ 
    Secondary mechanism: View generates PDF from html template. It is triggered by a button click.
    BUG - View generates empty pdf file.
    """
    
    filename = 'details.pdf'
    template_name = 'cycle\calculation_detail.html'
    header_template = 'base_generic.html'

#Registration forms
def register_client(request):
    """ 
    Function performs registration of a Client user by inserting a new entery into User model. Registration can be performed 
    only by users with staff status hence restriction logic is applied in templates. Form is passed to user as a 
    POST request. After data is filled in, form is returned back to server where default and custom validators are applied. 
    If validation == true, User instance is created with group assigned to Clients, and user is redirected to 
    list of users with succss message displayed.
    If validation == false, User is prompted with clear form and error message displayed.
    """
    if request.method == "POST":
        form = NewUserForm(request.POST or None)
        if form.is_valid():
            user = form.save()
            group = Group.objects.get(name='Clients')
            user.groups.add(group)
            messages.success(request, "New client added sucessfully!" )
            return redirect('users')
        else:
            messages.error(request, "Data entered is either incorrect or inconsistent. Please try again." )
            form = NewUserForm()
    else:
        form = NewUserForm()
    return render (request=request, template_name="main/register.html", context={"NewUserForm":form})

def register_administrator(request):
    """ 
    Function performs registration of a Administrator user by inserting a new entery into User model. Registration can be performed 
    only by users with staff status hence restriction logic is applied in templates. Form is passed to user as a 
    POST request. After data is filled in, form is returned back to server where default and custom validators are applied. 
    If validation == true, User instance is created with group assigned to Administrators and staff status set to true. User is redirected to 
    list of users with succss message displayed.
    If validation == false, User is prompted with clear form and error message displayed.
    """
    if request.method == "POST":
        form = NewUserForm(request.POST or None)
        if form.is_valid():
           user = form.save()
           group = Group.objects.get(name='Administrators')
           user.groups.add(group)
           user.is_staff = True
           user.save()
           messages.success(request, "New administrator added sucessfully!" )
           return redirect('users')
        else:
            messages.error(request, "Data entered is either incorrect or inconsistent. Please try again." )
            form = NewUserForm()
    else:
        form = NewUserForm()
    return render (request=request, template_name="main/register.html", context={"NewUserForm":form})
