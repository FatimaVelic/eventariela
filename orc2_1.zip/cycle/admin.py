from django.contrib import admin

from .models import Calculation

""" 
Defines data and the way its displayed on Django administrative dashboard for superusers
"""

@admin.register(Calculation)
class CalculationAdmin(admin.ModelAdmin):
    list_display = ("id", "userid", "time_calculated", "Tsrcin", "Tsrcout", "Qsrc", "result", "result_ts", "result_tq")
    list_filter = ("id", "userid", "time_calculated", "Tsrcin", "Tsrcout", "Qsrc", "result")
    fieldsets = (
        (None, {
            'fields': ('userid', 'time_calculated')}),
        ("User inputs", 
         {"fields" : ("Tsrcin", "Tsrcout", "Qsrc")}), 
        ("Results", 
         {"fields" : ("result", "result_ts", "result_tq")})
        )