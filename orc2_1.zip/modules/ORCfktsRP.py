# -*- coding: utf-8 -*-
"""
Created on Thu Jan 30 11:54:17 2020

@author: DEBIEKNJ

ORCfktsRP.py contains necessary and helper functions to carry out full 
ORC cycle calculation, thus it is required by calculation.py module.

Module relies on two other modules from the bundle:
1. turbocond.py - iterates regeneration/condensation process and the turbine process
2. morcevap.py - iterates evaporation pressure und mass flow

In order to operate fully and properly, module requires following to be installed:
- numpy
- pandas
- os
- REFPROP (API and database) 
"""

import numpy as np

import os; os.environ['RPPREFIX'] = 'C:/REFPROP'
from ctREFPROP.ctREFPROP import REFPROPFunctionLibrary
RP = REFPROPFunctionLibrary(os.environ['RPPREFIX'])
RP.SETPATHdll(os.environ['RPPREFIX'])
MASS_BASE_SI = RP.GETENUMdll(0, "MASS BASE SI").iEnum

Rallg = 8.31446261815324

# Berechnung des Massenstrom
def mflowkrit(Akrit,p0,T0,kappa,Molmasse,M):
    """
    Calculation of the critical mass flow through a choked nozzle.

    Parameters
    ----------
    Akrit : float
        Smallest flow area of the nozzle [m²].
    p0 : float or integer
        Total stagnation pressure in [Pa].
    T0 : float or integer
        Total stagnation temperature in [K].
    kappa : float
        Isentropic exponent of the medium [-].
    Molmasse : float
        Molar mass of the medium [kg/mol].
    M : integer
        Mach number of the choked flow [always 1].

    Returns
    -------
    mflow : integer
        Critical mass flow in [kg/s].

    """
    
    R = Rallg/Molmasse
    if kappa < 1:
        kappa = 1.1
        print('kappa Berechnung nicht erfolgreich') #Kappa calculation not successful
    mflow = (Akrit*p0/np.sqrt(T0))*np.sqrt(kappa/R)*M*(1+0.5*(kappa-1)*M**2)**-((kappa+1)/(kappa-1)/2)
    return (mflow)

# Berechnung des Massenstrom
def mflowkritmedium(Akrit,p0,T0,medium,M):
    """
    Calculation of the critical mass flow through a choked nozzle.

    Parameters
    ----------
    Akrit : float
        Smallest flow area of the nozzle [m²].
    p0 : float or integer
        Total stagnation pressure in [Pa].
    T0 : float or integer
        Total stagnation temperature in [K].
    medium : string
        Name of the medium to be calculated (i.e. ethylbenzene, methylcyclohexane,...).
    M : integer
        Mach number of the choked flow [always 1].

    Returns
    -------
    mflow : integer
        Critical mass flow in [kg/s].

    """ 
    r = RP.REFPROPdll(medium,"PT","CP/CV",MASS_BASE_SI,0,0,p0,T0,[1.0])
    kappa = r.Output[0]
    
    r = RP.REFPROPdll(medium,"PT","MM",MASS_BASE_SI,0,0,p0,T0,[1.0])
    Molmasse = r.Output[0]   
    
    R = Rallg/Molmasse
    mflow = (Akrit*p0/np.sqrt(T0))*np.sqrt(kappa/R)*M*(1+0.5*(kappa-1)*M**2)**-((kappa+1)/(kappa-1)/2)
    return (mflow)

# Berechnung der Schallgeschwindigkeit
def schall(machzahl,p0,T0,medium):
    """
    Calculates the absolute velocity of the flow at the achieved Mach number.

    Parameters
    ----------
    machzahl : float
        Mach Number at the exit of the laval nozzle.
    p0 : float or integer
        Total stagnation pressure in [Pa].
    T0 : float or integer
        Total stagnation temperature in [K].
    medium : string
        Name of the medium to be calculated (i.e. ethylbenzene, methylcyclohexane,...).

    Returns
    -------
    a : float
        Velocity at nozzle exit in [m/s].

    """

    r = RP.REFPROPdll(medium,"PT","CP/CV",MASS_BASE_SI,0,0,p0,T0,[1.0])
    kappa = r.Output[0]
    
    r = RP.REFPROPdll(medium,"PT","MM",MASS_BASE_SI,0,0,p0,T0,[1.0])
    Molmasse = r.Output[0]   
    
    R = Rallg/Molmasse
    # Berechnung der / Calculation of
    T = T0*(1+(kappa-1)/2*machzahl)**(-1)
    a = np.sqrt(kappa*R*T)
    return (a)

# Berechnung des Sättigungstemperatur
def Tsat(p,medium):
    """
    Calculates the saturation temperature of the medium at a given pressure using the REFPROP DLL.

    Parameters
    ----------
    p : float or integer
        Pressure in [Pa].
    medium : string
        Name of the medium (i.e. 'ethylbenzene','methylcyclohexane',...).

    Returns
    -------
    Tsat : float
        Saturation temperature in [K] of the medium at the given pressure.

    """
    
    r = RP.REFPROPdll(medium,"PQ","T",MASS_BASE_SI,0,0,p,1,[1.0])
    Tsat = r.Output[0]
    
    return (Tsat)

# Berechnung des Sättigungstemperatur
def psat(T,medium):
    """
    Calculates the saturation pressure of the medium at a given temperature using the REFPROP DLL.

    Parameters
    ----------
    T : float or integer
        Temperature of the medium in [K].
    medium : string
        Name of the medium (i.e. 'ethylbenzene','methylcyclohexane',...).

    Returns
    -------
    psat : float
        Saturation pressure in [Pa] of the medium at the given Temperature.

    """
    
    r = RP.REFPROPdll(medium,"TQ","P",MASS_BASE_SI,0,0,T,1,[1.0])
    psat = r.Output[0]
    
    return (psat)

# Berechnung der Mediendichte
def rhomedium(p,T,medium):
    """
    Calculates the density of the medium at a given pressure/temperature.

    Parameters
    ----------
    p : float or integer
        Pressure in [Pa].
    T : float or integer
        Temperature in [K].
    medium : string
        Name of the medium (i.e. 'ethylbenzene','methylcyclohexane',...).

    Returns
    -------
    rho : float
        Density of the medium in [kg/m³].

    """
    
    r = RP.REFPROPdll(medium,"PT","D",MASS_BASE_SI,0,0,p,T,[1.0])
    rho = r.Output[0]
    
    return (rho)

def ckrit(kappa):
    return ((1+(kappa-1)/2)**(1/2))**(-1)

# Berechnung von Kappa von Gasen
def kappacalc(p,T,medium):
    """
    Calculated the isentropic exponent of the medium for a given pressure/temperature.

    Parameters
    ----------
    p : float or integer
        Pressure in [Pa].
    T : float or integer
        Temperature in [K].
    medium : string
        Name of the medium (i.e. 'ethylbenzene','methylcyclohexane',...).

    Returns
    -------
    kappa : float
        Isentropic exponent of the medium without unit [-].

    """
    
    r = RP.REFPROPdll(medium,"PT","CP/CV",MASS_BASE_SI,0,0,p,T,[1.0])
    kappa = r.Output[0]   
        
    return (kappa)

def deltah(p,T1,T2,medium):
    """
    Calculates the enthalpy difference of a given medium at constant pressure
    during a temperature change.

    Parameters
    ----------
    p : float or integer
        Pressure in [Pa].
    T1 : float or integer
        Temperature at the start of the change in [K].
    T2 : float or integer
        Temperature at the end of the change in [K].
    medium : string
        Name of the medium (i.e. 'ethylbenzene','methylcyclohexane',...).

    Returns
    -------
    dh : float
        Enthalpie difference in [kJ/Kg]

    """
    
    r = RP.REFPROPdll(medium,"PT","H",MASS_BASE_SI,0,0,p,T1,[1.0])
    h1 = r.Output[0]
    r = RP.REFPROPdll(medium,"PT","H",MASS_BASE_SI,0,0,p,T2,[1.0])
    h2 = r.Output[0]

    dh = h2-h1
    return (dh)

# Berechnung des mittleren cp bei Wärmezu/-abfuhr
def cpmean(p,T1,T2,medium):
    """
    Calculates the mean heat capacity at constant pressure for a temperature change.

    Parameters
    ----------
    p : float or integer
        Pressure in [Pa].
    T1 : float or integer
        Temperature at the start of the change in [K].
    T2 : float or integer
        Temperature at the end of the change in [K].
    medium : string
        Name of the medium (i.e. 'ethylbenzene','methylcyclohexane',...).

    Returns
    -------
    cpmean : float
        Heat capacity at constant pressure for the given boundary conditions.

    """
    
    r = RP.REFPROPdll(medium,"PT","cp",MASS_BASE_SI,0,0,p,T1,[1.0])
    cp1 = r.Output[0]
    r = RP.REFPROPdll(medium,"PT","cp",MASS_BASE_SI,0,0,p,T2,[1.0])
    cp2 = r.Output[0]

    cpmean = (cp1+cp2)/2
    return (cpmean)

# Berechnung der Verdampfungsenthalpie
def phasechange(p,medium):
    """
    Calculates the evaporation enthalpy of a medium for the given pressure.

    Parameters
    ----------
    p : float or integer
        Pressure in [Pa].
    medium : string
        Name of the medium (i.e. 'ethylbenzene','methylcyclohexane',...).

    Returns
    -------
    hevap : float
        Evaporation enthalpy in [kJ/kg].

    """
    
    hevap = RP.REFPROPdll(medium,"PQ","HEATVAPZ",MASS_BASE_SI,0,0,p,0,[1.0]).Output[0]
    return hevap

def idealturbopower(mflow,Tein,pein,paus,medium):
    """
    Calculates the ideal power to be generated with the given expansion.

    Parameters
    ----------
    mflow : float
        Mass flow in [kg/s].
    Tein : float or integer
        Turbine inlet temperature in [K].
    pein : float or integer
        Turbine inlet pressure in [Pa].
    paus : float or integer
        Turbine outlet pressure in [Pa].
    medium : string
        Name of the medium (i.e. 'ethylbenzene','methylcyclohexane',...).

    Returns
    -------
    power : float
        Calculated ideal power that is available by the expansion in [W].

    """
    
    # Berechnung der Eingangsentropie / Calculation of the input entropy
    r = RP.REFPROPdll(medium,"PT","S",MASS_BASE_SI,0,0,pein,Tein,[1.0])
    Sin = r.Output[0]
    # Berechnung der Eingangsenthalpie / Calculation of the input enthalpy
    r = RP.REFPROPdll(medium,"PT","H",MASS_BASE_SI,0,0,pein,Tein,[1.0])
    Hin = r.Output[0]
    # Berechnung der isentropen Ausgangsenthalpie / Calculation of the isentropic starting enthalpy
    r = RP.REFPROPdll(medium,"PS","H",MASS_BASE_SI,0,0,paus,Sin,[1.0])
    Hout = r.Output[0]
    
    # Berechnung der Leistung aus Massenstrom und Enthalpiedifferenz / Calculation of the power from mass flow and enthalpy difference
    power = mflow*(Hout - Hin)
    return (power)


def morcevap(Akrit,mediumORC,msrc,cpsrc,Qsrc,Tsrcin,Tsrcout,T2,T45,p34,dTsrcpinch,M):
    """
    Iterates the evaporation pressure und mass flow depending on the given
    boundary conditions. These are mostly independent from turbine operation and condensation.
    In recuperated processes depends on the preheating.

    Parameters
    ----------
    Akrit : float or integer
        Narrowest cross section of the turbine nozzle in [m²].
    mediumORC : string
        Name of the medium (i.e. 'ethylbenzene','methylcyclohexane',...).
    msrc : float or integer
        Mass flow of the source medium in [kg/s].
    cpsrc : float or integer
        Heat capacity of the source medium at constant pressure [kJ/kgK].
    Qsrc : float or integer
        Available thermal power of the heat source.
    Tsrcin : float or integer
        Inlet temperature of the heat source in [K].
    Tsrcout : float or integer
        Outlet temperature of the heat source in [K].
    T2 : float or integer
        Inlet temperature of the ORC Medium entering the evaporator in [K].
    T45 : float or integer
        Temperature difference between evaporation temperature und superheated temperature in [K].
    p34 : float or integer
        Evaporation pressure of the ORC Medium in the evaporator in  [Pa].
    dTsrcpinch : float or integer
        Allowable smallest temperature difference between heat source and ORC Medium in [K].
    M : float
        Mach number at the narrowest cross section (usually 1), expert parameter.

    Returns
    -------
    morc : float
        Mass flow in the ORC cycle in [kg/s].
    p34 : float
        Evaporation pressure in the ORC cycle in [Pa].
    T34 : float
        Evaporation temperature in the ORC cycle in [K].
    TsrcD : float
        Source outlet temperature in [K].
    Qph : float
        Thermal power used for liquid heatup from T2 to T34 in [W].
    Qevap : float
        Thermal power used for evaporation at T34 in [W].
    Qsh : float
        Thermal power used for superheating the medium from T34 to T5 in [W].
    Qtotal : float
        Total thermal power transferred to the ORC Medium in [W].

    """
    

    # Molmasse ORC Medium ermitteln / Determine the molar mass of the ORC medium
    r = RP.REFPROPdll(mediumORC,"PQ","MM",MASS_BASE_SI,0,0,p34,1,[1.0])
    molmasse = r.Output[0]

    stopper = 0 # Indikator für while Schleife initialisieren / Initialize indicator for while loop
    counter = 0
    
    while stopper == 0:
        
        r = RP.REFPROPdll(mediumORC,"PQ","T",MASS_BASE_SI,0,0,p34,1,[1.0])
        T34 = r.Output[0]
        
        # Berechnung Massenstrom Düse mit engstem Querschnitt und Verdampfungsparametern / Calculation of the mass flow nozzle with the narrowest cross-section and evaporation parameters
        kappa = kappacalc(p34,T34+T45,mediumORC)
        if kappa < 0:
            break
        morc = mflowkrit(Akrit,p34,T34+T45,kappa,molmasse,M)
        
        # Berechnung der Wärmekapzitäten und Verdampfungsenthalpien / Calculation of heat capacities and evaporation enthalpies
        dh23 = deltah(p34,T2,T34-0.2,mediumORC)
        hevap = phasechange(p34,mediumORC)
        dh45 = deltah(p34,T34+0.2,T34+T45,mediumORC)
        
        # Berechnung der Verdampfungsleistung / Calculation of the evaporation capacity
        Qph = morc * dh23
        Qevap = morc * hevap
        Qsh = morc * dh45
        Qtotal = Qph + Qevap + Qsh
        # Berechnung der Quellenabkühlung / Calculation of the source cooling
        dTevap = (Qevap+Qsh)/(msrc*cpsrc)
        # Berechnung der maximalen Verdampfungstemperatur / Calculation of the maximum evaporation temperature
        T34max = Tsrcin - dTsrcpinch - dTevap
        # Berechnung der Austrittstemperatur der Quelle / Calculation of the outlet temperature of the source
        TsrcD = Tsrcin - Qtotal/(msrc*cpsrc)
        
        if (np.abs(Qsrc/Qtotal-1) < 0.001) or (np.abs(T34/T34max-1) < 0.004):
            stopper = 1
        
        # Vergleich Pinchabstand und korrektur Verdampfungsdruck / Comparison of pinch distance and correction of evaporation pressure
        if T34 > T34max or Qsrc < Qtotal:
            p34 = p34 - 1000
        elif T34 < T34max:
            p34 = p34 + 660
        
        counter = counter + 1
        if counter > 3e5:
            stopper = 1
   
    return (morc,p34,T34,TsrcD,Qph,Qevap,Qsh,Qtotal)

def turbcond(stopper,T2,p6,T6,S6,T1011,Tsc,effturb,effreku,mediumORC,morc,Qsrc,T_senke_in,cp_senke,msenke,pinch_kond,dp89):
    """
    Iterates the boundary conditions of the regeneration/condensation process and the turbine process.
    The condensation is dependend on the turbine process an vice versa.

    Parameters
    ----------
    stopper : integer
        Variable that stops the iteration if certain conditions are met.
    T2 : float or integer
        Temperature of the ORC Medium after preheating in the recuperator in [K].
    p6 : float or integer
        Pressure at the turbine inlet in [Pa].
    T6 : float or integer
        Temperature at the turbine inlet in [K].
    S6 : float or integer
        Entropy at the turbine inlet in [J/kgK].
    T1011 : float or integer
        Condensation temperature in [K].
    Tsc : float or integer
        Subcooling Temperature in [K].
    effturb : float
        Isentropic turbine efficiency [-].
    effreku : float
        Efficiency of the heat regeration of the recuperator [-].
    mediumORC : string
        Name of the medium (i.e. 'ethylbenzene','methylcyclohexane',...).
    morc : float
        Mass flow of the ORC cycle in [kg/s].
    Qsrc : float or integer
        Thermal power of the heat source in [W].
    T_senke_in : float or integer
        Inlet Temperature of the heat sink in [K].
    cp_senke : float
        Heat capacity at constant pressure of the heat sink medium in [J/kgK].
    msenke : float
        Mass flow of the heat sink medium in [kg/s].
    pinch_kond : float or integer
        Minimum allowable temperature difference between the heat sink and the ORC medium in [K].
    dp89 : float or integer
        Pressure loss due to regeneration/condensation between turbine an condensator in [Pa].

    Returns
    -------
    T0 : float
        Temperature at feed pump in [K].
    T2 : float
        Temperature of liquid after recuperation in [K].
    T8 : float
        Temperature after turbine [K].
    T9 : TYPE
        Temperature of gas after recuperation in [K].
    stopper : integer
        Variable used to control the iteration.
    T1011 : float
        Temperature of condensation in [K].
    p1011 : float
        Pressure of condensation in [Pa].
    pi : float
        Pressure ratio of the turbine.
    Qcond : float
        Thermal power of the condensation.
    Pmech : float
        Mechanical power delivered by the turbine in [W].
    Pel : float
        Electrical power delivered by the turbine in [W].
    thermaleff : float
        Efficiency of the energy transfer from thermal to electrical energy.
    Qregenerate : float 
        Thermal power of the recuperation in [W].
    pinchabstand : float
        Minimum temperature difference between the heat sink medium and the ORC medium in [K].

    """
    
    counter = 0
    
    while stopper == 0:
        
        r = RP.REFPROPdll(mediumORC,"TQ","P",MASS_BASE_SI,0,0,T1011,1,[1.0])
        p1011 = r.Output[0]

        # Berechnung Turbinenaustrittstemperatur (mit Druckverhältnis und Effizienz) / Calculation of turbine outlet temperature (with pressure ratio and efficiency)
        r = RP.REFPROPdll(mediumORC,"SP","H",MASS_BASE_SI,0,0,S6,p1011+dp89,[1.0])
        H8is = r.Output[0]
        #Berechnung der isentropen Enthalpie nach der Turbine / Calculation of the isentropic enthalpy after the turbine
        r = RP.REFPROPdll(mediumORC,"PT","H",MASS_BASE_SI,0,0,p6,T6,[1.0])
        H6 = r.Output[0]
        #Berechnung der Enthalpie vor der Turbine / Calculation of the enthalpy in front of the turbine
        dH = (H8is - H6)*effturb #Berechnung der durch Turbine entzogenen Enthalpie mit Wirkungsgrad / Calculation of the enthalpy withdrawn by the turbine with efficiency
        H8 = H6+dH # Berechnug der Enthalpie nach der Turbine / Calculation of the enthalpy after the turbine
        Pmech = morc * dH # Berechnung der entzogenen Leistung / Calculation of the withdrawn service
        Pel = Pmech*0.95 # Berechnung der elektrischen Leistung mit Wirkungsgrad / Calculation of electrical power with efficiency
        thermaleff = Pel/Qsrc # Berechnung der elektrischen Effizienz / Calculation of electrical efficiency
        r = RP.REFPROPdll(mediumORC,"PH","T",MASS_BASE_SI,0,0,p1011+dp89,H8,[1.0])
        T8 = r.Output[0]
        
        # Berechnung der Rekuperation / Calculation of recuperation
        r = RP.REFPROPdll(mediumORC,"PT","H",MASS_BASE_SI,0,0,p1011,T8,[1.0])
        hpc1 = r.Output[0]
        r = RP.REFPROPdll(mediumORC,"PT","H",MASS_BASE_SI,0,0,p1011,T1011+0.1,[1.0])
        hpc2 = r.Output[0]     
        hpcmax = hpc1-hpc2
        hregenerate = hpcmax * effreku # Berechnung der spezifischen Rekuperation / Calculation of the specific recuperation
        Qregenerate = hregenerate * morc # Berechnung der Rekuperationsleistung / Calculation of the recuperation performance
        #Berechnung der Eigenschaften nach Rekuperation / Calculation of the properties after recuperation
        r = RP.REFPROPdll(mediumORC,"PT","H",MASS_BASE_SI,0,0,p1011+dp89,T8,[1.0])
        H9 = r.Output[0] - hregenerate
        r = RP.REFPROPdll(mediumORC,"PH","T",MASS_BASE_SI,0,0,p1011+dp89/2,H9,[1.0])
        T9 = r.Output[0]
   
        # Berechnung Kondensationsleistung / Calculation of condensation capacity
       
        # Enthitzung / Deheating 
        r = RP.REFPROPdll(mediumORC,"TQ","H",MASS_BASE_SI,0,0,T9,1,[1.0]) #Enthalpie nach Turbine und Rekuperator / Enthalpy after the turbine and recuperator
        hsh1 = r.Output[0]
        r = RP.REFPROPdll(mediumORC,"TQ","H",MASS_BASE_SI,0,0,T1011,1,[1.0]) # Enthalpie vor Kondensation / Enthalpy before condensation
        hsh2 = r.Output[0]     
        hpc = hsh2-hsh1
        #Kondensation
        hcond = phasechange(p1011,mediumORC)
        # Unterkühlung / Supercooling 
        Qcond = Qsrc + Pmech
        hsc = Qcond/morc - hpc - hcond - hregenerate
        
        if hsc < 0:
            pinch_kond += 1 #Erhöhung Pinchabstand wenn keine Unterkühlung erreicht wird. / Increase the pinch distance if no supercooling is achieved

        #Berechnung der Quellentemperatur nach Enthitzung / Calculation of the source temperature after desuperheating
        Tiii = T_senke_in + (morc*(hsc+hcond))/(cp_senke*msenke)
        
        pinchabstand = T1011 - Tiii # Berechnung des Pinchabstands / Calculation of the pinch distance

        #Kontrollbedingungen dass der Pinchabstand erreicht ist mit Anpassung der Kondensationstemperatur / Control conditions that the pinch distance is reached with adjustment of the condensation temperature
        if pinchabstand < pinch_kond:
            T1011 = T1011 + 1
        elif pinchabstand > pinch_kond:
            T1011 = T1011 - 1

        # Abbruchkriterium dass der gewünschte Pinchabstand erreicht ist / Abort criterion that the desired pinch distance has been reached
        if np.abs(pinchabstand/pinch_kond-1) < 0.3:#01:
            stopper = 1
        
        counter = counter + 1
        if counter > 1e4:
            stopper = 1
        
        H0 = H9-hpc-hcond-hsc
        try:
            r = RP.REFPROPdll(mediumORC,"PH","T",MASS_BASE_SI,0,0,p1011,H0,[1.0])
            T0 = r.Output[0]
        except:
            stopper = 1
            T0 = 273.15
            
        pi = p6/(p1011+dp89)
        r = RP.REFPROPdll(mediumORC,"PT","H",MASS_BASE_SI,0,0,p6,T0,[1.0])
        H2 = r.Output[0] + hregenerate
        r = RP.REFPROPdll(mediumORC,"PH","T",MASS_BASE_SI,0,0,p6,H2,[1.0])
        T2 = r.Output[0]     

    return (T0,T2,T8,T9,stopper,T1011,p1011,pi,Qcond,Pmech,Pel,thermaleff,Qregenerate,pinchabstand)
    
def ORC(Akrit,mediumORC,msrc,Qsrc,Tsrcin,Tsrcout,T2,T45,p34,\
        p1011,T110,effturb,effreku,Tsinkin,cpsink,msink,dTsrcpinch,dTsinkpinch,dp56,\
            dp89,M):
    """
    Iterates the full ORC Process by combining morcevap and turbcond modules.

    Parameters
    ----------
    Akrit : float
        Narrowest cross section in the turbine nozzle in [m²].
    mediumORC : string
        Name of the medium ORC (i.e.'ethylbenzene','methylcyclohexane',etc...).
    msrc : flaot
        Mass flow of the heat source in [kg/s].
    Qsrc : float or integer
        Thermal heat available from the heat source in [W].
    Tsrcin : float or integer
        Inlet temperature of the heat source in [K].
    Tsrcout : float or integer
        Outlet temperature of the heat source in [K].
    T2 : float
        Temperature of the ORC medium after rekuperation in [K].
    T45 : float or integer
        Temperature difference between evaporation and superheated steam in [K].
    p34 : float
        Evaporation pressure of the ORC Process in [Pa].
    p1011 : float
        Condensation pressure of the ORC Process in [Pa].
    T1011 : float
       Temperature of condensation in [K].
    effturb : flaot
        Turbine efficiency [-]. Typical == 0.7.
    effreku : float
        Recuperation efficiency [-]. No Rekuperation == 0.
    Tsinkin : float or integer
        Inlet temperature of the heat sink in [K].
    cpsink : float
        Heat capacity at constant pressure of the heat sink medium [J/kgK].
    msink : float or integer
        Mass flow of the heat sink in [kg/s].
    dTsrcpinch : float or integer
        Minimum temperature difference between source medium and ORC evaporation in [K].
    dTsinkpinch : float or integer
        Minimum temperature difference between sink medium and ORC condensation in [K].
    dp56 : float or integer
        Pressure loss between evaporation and turbine inlet in [Pa].
    dp89 : float or integer
        Pressure loss between turbine outlet and condensation in [Pa].
    M : float or integer
        Mach number at the narrowest cross section, usually 1. Expert parameter.


    Returns
    -------
    morc : float
        Mass flow of the ORC cycle in [kg/s].
    T0 : float
        Total stagnation temperature in [K].
    T2 : float
        Temperature at the end of the change in [K].
    T34 : float
        Evaporation temperature in the ORC cycle in [K].
    T5 : float
         Temperature in the evaporator after overheating in [K].
    T6 : float
        Temperature at the turbine inlet in [K].
    T8 : float
        Temperature after turbine in [K].
    T9 : float
        Temperature of gas after recuperation in [K].
    T1011 : float
        Temperature of condensation in [K].
    p34 : float
        Evaporation pressure of the ORC Medium in the evaporator in [Pa].
    p5 : float
        Pressure of the evaporator after overheating in [Pa].
    p6 : float
        Pressure at the turbine inlet in [Pa].
    p1011 : float
        Pressure of condensation in [Pa].
    pi : float
        Pressure ratio of the turbine.
    Qcond : float
        Thermal power of the condensation.
    Pmech : float
        Mechanical power delivered by the turbine in [W]..
    Pel : float
        Electrical power delivered by the turbine in [W].
    thermaleff : float
        Efficiency of the energy transfer from thermal to electrical energy.
    Qregenerate : float
        Thermal power of the recuperation in [W].
    Qtotal : float
        Total thermal power transferred to the ORC Medium in [W]..
    dTsinkpinch : float or integer
        Minimum temperature difference between sink medium and ORC condensation in [K]. 
    """

    from modules.morcevap import morcevap
    from modules.turbcond import turbcond
    
    check = 1
    T0 = 250
    
    while check > 0.01 and T0 != 273.15:
        [morc,p34,T34,TsrcD,Qph,Qevap,Qsh,Qtotal] = morcevap(Akrit,mediumORC,msrc,Qsrc,Tsrcin,Tsrcout,T2,T45,dTsrcpinch,M)
        
        T2start = T2 # T2 aus morcevap als Startwert für turbcond / T2 from morcevap as a starting value for turbcond
        p5 = p34 # überhitzter Dampf mit gleichem Druck wie gesättigter Dampf / Superheated steam with the same pressure as saturated steam
        T5 = T34+T45 # Überhitzungstemperatur / Overheating temperature
        p6 = p34 - dp56 # Druckverlust Dampf bis Turbinenvolute / Pressure loss from steam to turbine volume
        
        DT56 = 1 # Temperaturverlust zwischen Verdampfer und Ringraum vor Düse / Loss of temperature between the evaporator and the annular space in front of the nozzle
        T6 = T5-DT56 # Temperatur vor Turbine / Temperature in front of the turbine
        r = RP.REFPROPdll(mediumORC,"PT","S",MASS_BASE_SI,0,0,p6,T6,[1.0])
        S6 = r.Output[0]  # Entropie vor Turbine
        
        [T0,T2,T8,T9,T1011,p1011,pi,Qcond,Pmech,Pel,thermaleff,Qregenerate,pinchabstand] = \
        turbcond(T2,p6,T6,S6,p1011,effturb,effreku,mediumORC,morc,Qsrc,Tsinkin,cpsink,msink,dTsinkpinch,dp89,T110)
        
        check = np.abs(T2/T2start-1) # Vergleich ob sich ein neuer Startwert für T2 ergeben hat / Comparison of whether a new starting value has resulted for T2
        
    return (morc,T0,T2,T34,T5,T6,T8,T9,T1011,p34,p5,p6,p1011,pi,Qcond,Pmech,Pel,thermaleff,Qregenerate,Qtotal,dTsinkpinch)


def morcevapcond(Akrit,mediumORC,msrc,mediumsrc,Qsrc,psrc,Tsrcin,Tsrcout,T2,T45,p34,dTsrcpinch):
    """
    #Performs condensation process in hot sink.
    
    Parameters
    ----------
    Akrit : float or integer
        Narrowest cross section of the turbine nozzle in [m²].
    mediumORC : string
        Name of the medium (i.e. 'ethylbenzene','methylcyclohexane',...).
    msrc : float or integer
        Mass flow of the source medium in [kg/s].
    mediumsrc : string
        Name of the medium (i.e. 'ethylbenzene','methylcyclohexane',...).
    Qsrc : float or integer
        Available thermal power of the heat source.
    psrc : float or integer
        Pressure of the source in [Pa].
    Tsrcin : float or integer
        Inlet temperature of the heat source in [K].
    Tsrcout : float or integer
        Outlet temperature of the heat source in [K].
    T2 : float or integer
        Inlet temperature of the ORC Medium entering the evaporator in [K].
    T45 : float or integer
        Temperature difference between evaporation temperature und superheated temperature in [K].
    p34 : float or integer
        Evaporation pressure of the ORC Medium in the evaporator in  [Pa].
    dTsrcpinch : float or integer
        Allowable smallest temperature difference between heat source and ORC Medium in [K].

    Returns
    -------
    mcrit : float
        Mass flow nozzle with the narrowest cross-section and evaporation parameters
    p34 : float
        Evaporation pressure in the ORC cycle in [Pa].
    T34 : float
        Evaporation temperature in the ORC cycle in [K].
    TsrcD : float
        Source outlet temperature in [K].
    Qph : float
        Thermal power used for liquid heatup from T2 to T34 in [W].
    Qevap : float
        Thermal power used for evaporation at T34 in [W].
    Qsh : float
        Thermal power used for superheating the medium from T34 to T5 in [W].
    Qtotal : float
        Total thermal power transferred to the ORC Medium in [W].
    Akrit : float
        Narrowest cross section of the turbine nozzle in [m²].
    """
    
    r = RP.REFPROPdll(mediumORC,"PQ","MM",MASS_BASE_SI,0,0,p34,1,[1.0])
    molmasse = r.Output[0] # Molmasse ORC Medium ermitteln / Determine the molar mass of the ORC medium
    stopper = 0 # Indikator für while Schleife initialisieren / Initialize indicator for while loop
    counter = 0
    
    TsrcD = Tsrcout
    
    while stopper == 0:
        # Verdampfungstemperatur für Startdruck berechnen / Calculate evaporation temperature for start pressure
        r = RP.REFPROPdll(mediumORC,"PQ","T",MASS_BASE_SI,0,0,p34,1,[1.0])
        T34 = r.Output[0]
        
        # Berechnung Massenstrom Düse mit engstem Querschnitt und Verdampfungsparametern / Calculation of the mass flow nozzle with the narrowest cross-section and evaporation parameters
        kappa = kappacalc(p34,T34,mediumORC)
        mcrit = mflowkrit(Akrit,p34,T34+T45,kappa,molmasse)
        
        # Berechnung der Wärmekapzitäten und Verdampfungsenthalpien / Calculation of heat capacities and evaporation enthalpies
        dh23 = deltah(p34,T2,T34-0.2,mediumORC)  
        hevap = phasechange(p34,mediumORC)
        dh45 = deltah(p34,T34+0.2,T34+T45,mediumORC)
        
        # Berechnung der Verdampfungsleistung / Calculation of the evaporation capacity
        Qph = mcrit * dh23
        Qevap = mcrit * hevap
        Qsh = mcrit * dh45
        Qtotal = Qph + Qevap + Qsh
        
        
        # Kondensierende Quelle, daher iterative Berechnung der Quelle / Condensing source, therefore iterative calculation of the source

        # Kondensationstemperatur / Condensation temperature
        r = RP.REFPROPdll(mediumORC,"PQ","T",MASS_BASE_SI,0,0,psrc,1,[1.0])
        Tsrccond = r.Output[0]
        # Enthitzungswärme / Desuperheating ?
        cpsrcsh = cpmean(psrc,Tsrcin,Tsrccond+0.1,mediumsrc)
        dtsrcsh = Tsrcin-Tsrccond
        Qsrcsh = msrc*cpsrcsh*dtsrcsh
        # Kondensationswärme / Heat of condensation
        dhsrccond = phasechange(psrc, mediumsrc)
        Qsrccond = msrc*dhsrccond
        # Unterkühlung / Supercooling
        cpsrcsc = cpmean(psrc,Tsrcout,Tsrccond+0.1,mediumsrc)
        dtsrcsc = Tsrccond - Tsrcout
        Qsrcsc = msrc*cpsrcsc*dtsrcsc
        Qsrctotal = Qsrcsh+Qsrccond+Qsrcsc
       
        T34max = Tsrccond - dTsrcpinch

        
        # Berechnung der Austrittstemperatur der Quelle / Berechnung der Austrittstemperatur der Quelle
        if Qtotal < (Qsrcsh + Qsrccond):
            TsrcD = Tsrccond
            print('Quelle konnte nicht vollständig kondensiert werden, Akrit erhöhen')
        else:
            TsrcD = Tsrccond - Qsrcsc/(msrc*cpsrcsc)
        
        # Vergleich Pinchabstand und korrektur Verdampfungsdruck / Comparison of pinch distance and correction of evaporation pressure
        if Qsrc < Qtotal:
            p34 = p34 - 2000
        else:
            p34 = p34 + 1670
        
        """
        if Qsrc < Qtotal and T34 > T34max:
            Akrit = Akrit + 1e-6
            #print('Der kritische Querschnitt wurde erhöht da {0:1.3f} > 0.01'.format(Qsrctotal/Qtotal-1))
        """
            
        """    
        p34 = np.min([p34,13e5])
        if p34 == 13e5:
            print('Maximaldruck der Verdampfung ausgeschöpft, Akrit erhöhen')
            
        """    
        
        counter = counter + 1
        if counter > 1e3:
            stopper = 1
            print('morcevapcond maximale Iterationszahl erreicht')

        if (Qsrctotal/Qtotal-1 > 0.01) and (T34 < T34max):
            stopper = 1
    
    return (mcrit,p34,T34,TsrcD,Qph,Qevap,Qsh,Qtotal,Akrit)


    
def ORCcond(Akrit,mediumORC,msrc,mediumsrc,Qsrc,psrc,Tsrcin,Tsrcout,T2,T45,p34,T1011,T110,effturb,effreku,Tsinkin,cpsink,msink,dTsrcpinch,dTsinkpinch,dp56,dp89):
    """
    Iterates the full ORC Process by combining morcevapcond and turbcond routines.

    Parameters
    ----------
    Akrit : float
        Narrowest cross section in the turbine nozzle in [m²].
    mediumORC : string
        Name of the medium ORC (i.e.'ethylbenzene','methylcyclohexane',etc...).
    msrc : flaot
        Mass flow of the heat source in [kg/s].
    mediumsrc : string
        Name of the medium source (i.e.'ethylbenzene','methylcyclohexane',etc...).
    Qsrc : float or integer
        Thermal heat available from the heat source in [W].
    psrc : float or integer
        Pressure of the source in [Pa].
    Tsrcin : float or integer
        Inlet temperature of the heat source in [K].
    Tsrcout : float or integer
        Outlet temperature of the heat source in [K].
    T2 : float
        Temperature of the ORC medium after rekuperation in [K].
    T45 : float or integer
        Temperature difference between evaporation and superheated steam in [K].
    p34 : float
        Evaporation pressure of the ORC Process in [Pa].
    T1011 : float
        Temperature of condensation in [K].
    effturb : flaot
        Turbine efficiency [-]. Typical == 0.7.
    effreku : float
        Recuperation efficiency [-]. No Rekuperation == 0.
    Tsinkin : float or integer
        Inlet temperature of the heat sink in [K].
    cpsink : float
        Heat capacity at constant pressure of the heat sink medium [J/kgK].
    msink : float or integer
        Mass flow of the heat sink in [kg/s].
    dTsrcpinch : float or integer
        Minimum temperature difference between source medium and ORC evaporation in [K].
    dTsinkpinch : float or integer
        Minimum temperature difference between sink medium and ORC condensation in [K].
    dp56 : float or integer
        Pressure loss between evaporation and turbine inlet in [Pa].
    dp89 : float or integer
        Pressure loss between turbine outlet and condensation in [Pa].

    Returns
    -------
    morc : float
        Mass flow of the ORC cycle in [kg/s].
    T0 : float
        Total stagnation temperature in [K].
    T2 : float
        Temperature at the end of the change in [K].
    T34 : float
        Evaporation temperature in the ORC cycle in [K].
    T5 : float
         Temperature in the evaporator after overheating in [K].
    T6 : float
        Temperature at the turbine inlet in [K].
    T8 : float
        Temperature after turbine in [K].
    T9 : float
        Temperature of gas after recuperation in [K].
    T1011 : float
        Temperature of condensation in [K].
    p34 : float
        Evaporation pressure of the ORC Medium in the evaporator in [Pa].
    p5 : float
        Pressure of the evaporator after overheating in [Pa].
    p6 : float
        Pressure at the turbine inlet in [Pa].
    p1011 : float
        Pressure of condensation in [Pa].
    pi : float
        Pressure ratio of the turbine.
    Qcond : float
        Thermal power of the condensation.
    Pmech : float
        Mechanical power delivered by the turbine in [W]..
    Pel : float
        Electrical power delivered by the turbine in [W].
    thermaleff : float
        Efficiency of the energy transfer from thermal to electrical energy.
    Qregenerate : float
        Thermal power of the recuperation in [W].
    Qtotal : float
        Total thermal power transferred to the ORC Medium in [W]..
    dTsinkpinch : float or integer
        Minimum temperature difference between sink medium and ORC condensation in [K]. 
    """
    
    check = 1
    
    while check > 0.001:
        [morc,p34,T34,TsrcD,Qph,Qevap,Qsh,Qtotal,Akrit] = morcevapcond(Akrit,mediumORC,msrc,mediumsrc,Qsrc,psrc,Tsrcin,Tsrcout,T2,T45,p34,dTsrcpinch)
    
        T2start = T2
        p5 = p34
        T5 = T34+T45
        
        p6 = p34 - dp56
        
        DT56 = 1 # Temperaturverlust zwischen Verdampfer und Ringraum vor Düse / Loss of temperature between the evaporator and the annular space in front of the nozzle
        T6 = T5-DT56 # Temperatur vor Turbine / Temperature in front of the turbine
        r = RP.REFPROPdll(mediumORC,"PT","S",MASS_BASE_SI,0,0,p6,T6,[1.0])
        S6 = r.Output[0]  
        
        [T0,T2,T8,T9,stopper,T1011,p1011,pi,Qcond,Pmech,Pel,thermaleff,Qregenerate,pinchabstand] = \
        turbcond(0,T2,p6,T6,S6,T1011,T110,effturb,effreku,mediumORC,morc,Qsrc,Tsinkin,cpsink,msink,dTsinkpinch,dp89)
        
        check = np.abs(T2/T2start-1)
        
        return (morc,T0,T2,T34,T5,T6,T8,T9,T1011,p34,p5,p6,p1011,pi,Qcond,Pmech,Pel,thermaleff,Qregenerate,Qtotal,dTsinkpinch)    
