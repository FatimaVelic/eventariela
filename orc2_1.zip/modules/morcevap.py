# -*- coding: utf-8 -*-
"""
Created on Fri Mar 19 09:21:09 2021

@author: DEBIEKNJ

morcevap.py iteraetes evaporation pressure and mass flow, 
and it is a helper module to ORCfktsRP.py module.

morcevap.py relies on ORCfktsRP.py module for helper functions.

In order to operate fully and properly, module requires following to be installed:
- numpy
- os
- REFPROP (API and database) 
"""
import os; os.environ['RPPREFIX'] = r'C:/REFPROP'
from ctREFPROP.ctREFPROP import REFPROPFunctionLibrary
RP = REFPROPFunctionLibrary(os.environ['RPPREFIX'])
RP.SETPATHdll(os.environ['RPPREFIX'])
MASS_BASE_SI = RP.GETENUMdll(0, "MASS BASE SI").iEnum
    
from modules.ORCfktsRP import kappacalc,deltah,phasechange,mflowkrit
import numpy as np

def morcevap(Akrit,mediumORC,msrc,Qsrc,Tsrcin,Tsrcout,T2,T45,dTsrcpinch,M):
    """
    Iterates the evaporation pressure und mass flow. These are mostly independent from turbine operation and condensation.
    In recuperated processes depends on the preheating.

    Parameters
    ----------
    Akrit : float or integer
        Narrowest cross section of the turbine nozzle in [m²].
    mediumORC : string
        Name of the medium (i.e. 'ethylbenzene','methylcyclohexane',...).
    msrc : float or integer
        Mass flow of the source medium in [kg/s].
    cpsrc : float or integer
        Heat capacity of the source medium at constant pressure [kJ/kgK].
    Qsrc : float or integer
        Available thermal power of the heat source.
    Tsrcin : float or integer
        Inlet temperature of the heat source in [K].
    Tsrcout : float or integer
        Outlet temperature of the heat source in [K].
    T2 : float or integer
        Inlet temperature of the ORC Medium entering the evaporator in [K].
    T45 : float or integer
        Temperature difference between evaporation temperature und superheated temperature in [K].
    dTsrcpinch : float or integer
        Allowable smallest temperature difference between heat source and ORC Medium in [K].
    M : float
        Mach number at the narrowest cross section (usually 1), expert parameter.

    Returns
    -------
    morc : float
        Mass flow in the ORC cycle in [kg/s].
    p34 : float
        Evaporation pressure in the ORC cycle in [Pa].
    T34 : float
        Evaporation temperature in the ORC cycle in [K].
    TsrcB : float
        Temperature of the heat source after cooling due to overheating in [K].
    TsrcC : float
        Temperature of the heat source after cooling by evaporation in [K].
    TsrcD : float
        Temperaure of the heat source after cooling by heating in [K].    
    Qph : float
        Thermal power used for liquid heatup from T2 to T34 in [W].
    Qevap : float
        Thermal power used for evaporation at T34 in [W].
    Qsh : float
        Thermal power used for superheating the medium from T34 to T5 in [W].
    Qtotal : float
        Total thermal power transferred to the ORC Medium in [W].
    
    """
    
    # Werte initialisieren
    counter = 0
    p34 = 3e5
    dp = 8e5
    
    r = RP.REFPROPdll(mediumORC,"PQ","MM",MASS_BASE_SI,0,0,p34,1,[1.0])
    molmasse = r.Output[0]
    cpsrc = Qsrc/(Tsrcin-Tsrcout)
    
    while 1:
        
        T34 = RP.REFPROPdll(mediumORC,"PQ","T",MASS_BASE_SI,0,0,p34,1,[1.0]).Output[0]
        
        # Berechnung Massenstrom Düse mit engstem Querschnitt und Verdampfungsparametern
        kappa = kappacalc(p34,T34+T45,mediumORC)
        # mflowkrit kann nur mit vernünftigen Kappa Werten berechnet werden, daher Abbruch wenn kappa negativ
        morc = mflowkrit(Akrit,p34,T34+T45,kappa,molmasse,M)
        
        # Berechnung der Wärmekapzitäten und Verdampfungsenthalpien
        dh23 = deltah(p34,T2,T34-0.2,mediumORC)
        hevap = phasechange(p34,mediumORC)
        dh45 = deltah(p34,T34+0.2,T34+T45,mediumORC)

        # Berechnung der Verdampfungsleistung
        Qph = morc * dh23
        Qevap = morc * hevap
        Qsh = morc * dh45
        Qtotal = Qph + Qevap + Qsh
        # Berechnung der Quellenabkühlung
        TsrcB = Tsrcin - Qsh/(msrc*cpsrc)
        TsrcC = TsrcB - Qevap/(msrc*cpsrc)
        TsrcD = TsrcC - Qph/(msrc*cpsrc)
             
        minpinch = np.min([Tsrcin - (T34+T45),TsrcB - T34,TsrcC - T34, TsrcD - T2])
        
        if (np.abs(Qsrc/Qtotal-1) < 0.001):
            print('Pinchabstand: '+str(minpinch))
            break
                
        if Qtotal < Qsrc:   
            p34 = p34 + dp
            dp = dp/2
        if Qtotal > Qsrc:
            p34 = p34 - dp
            dp = dp/2
        
        counter = counter + 1
        if counter > 12:
            break
        
    return(morc,p34,T34,TsrcD,Qph,Qevap,Qsh,Qtotal)

"""
# Beispielarbeitspunkt
Akrit = 150/1e6
mediumORC = 'Methylcyclohexane'
msrc = 1
Qsrc = 250e3
Tsrcin = 753
Tsrcout = 473 # eigentlich ungenutzt außer um evtl cp zu berechnen
T2 = 400 # vorwärmung
T45 = 5
pinchmin = 10

import time
lauf = 0

start = time.time()
while lauf < 10:
    [morc,p34,T34,TsrcD,Qph,Qevap,Qsh,Qtotal] = morcevap(Akrit,mediumORC,msrc,Qsrc,Tsrcin,Tsrcout,T2,T45,pinchmin)
    lauf += 1
end = time.time()

print('Ausführungszeit: '+str((end-start)/10)+' Schritte: '+str(counter))
"""