# -*- coding: utf-8 -*-
"""
Created on Tue Sep 14 12:05:13 2021

@author: DEBIEVEL

calculation.py is a version of Kreislaufberechnung.py created by DEBIEKNJ on Nov 30 09:34:52 2020.
This module for cointains ORC circle calculation with adjustments for web application development.
This module is supported by three other modules:

1. ORCfktsRP.py - contains necessary and helper functions to carry out full ORC cycle with recuperation
2. turbocond.py - iterates regeneration/condensation process and the turbine process
3. morcevap.py - iterates evaporation pressure und mass flow

In order to operate fully and properly, module requires REFPROP DLL.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


import sys
sys.path.append("/orc2/modules/")

from modules.ORCfktsRP import ORC,cpmean

import os; os.environ['RPPREFIX'] = 'C:\\REFPROP'
from ctREFPROP.ctREFPROP import REFPROPFunctionLibrary
RP = REFPROPFunctionLibrary(os.environ['RPPREFIX'])
RP.SETPATHdll(os.environ['RPPREFIX'])
MASS_BASE_SI = RP.GETENUMdll(0, "MASS BASE SI").iEnum

#Set working paths
workpath = os.getcwd()
savepath = workpath+"\cycle\static\operation"
os.chdir(savepath)


def cycle_simulation(Tsrcin, Tsrcout, Qsrc, Tsinkin, Tsinkout):
    """
    This function is a starting and ending point of the calculation since it provides a mechanism
    for assigning necesary valus and contains the returning values, performing unit conversions
    and graphing mechanisms for generating TS and TQ diagrams. 
    
    Parameters
    ----------
    Qsrc : float or integer
        Available thermal power of the heat source in [KW].
    Tsrcin : float or integer
        Inlet temperature of the heat source in [K].
    Tsrcout : float or integer
        Outlet temperature of the heat source in [K].
    Tsinkin : float
        Inlet temperature on the sink in [K].
    Tsinkout : float
        Outlet temperature on the sink in [K].

    Returns
    -------
    Pnetto : float
        Nett electrical power delivered by the turbine in [KW].
    Pel : float
        Gross electrical power delivered by the turbine in [KW].
    thermaleff : float
        Efficiency of the energy transfer from thermal to electrical energy.
    savepath : string
        path to directory where figure images are stored.

    """
    # Inputs    
    inputs = pd.read_excel('orc.xlsx',sheet_name='Eingabe',engine='openpyxl')
    thermaleff = 0.15
    Tkc = 273.15 #Celsius to Kelvin conversion coefficient 
    Pbc = 1e5 #Pascal to Bar conversion coefficient 
    
    Tsrcin = float(Tsrcin) + Tkc  
    Tsrcout = float(Tsrcout) + Tkc 
    Qsrc = float(Qsrc) * 1000
    Tsinkin = float(Tsinkin) + Tkc  
    Tsinkout = float(Tsinkout) + Tkc 
    #add psrc
    
    #Quelle
        
    psrc = inputs.Wert.iloc[2]*Pbc # Druck Quelle [Pa]
    dTsrcpinch = inputs.Wert.iloc[6] # Pinchabstand Quelle [K]
    mediumsrc = inputs.Wert.iloc[1] # Medium Quelle
    cpsrc = cpmean(psrc,Tsrcin,Tsrcout,mediumsrc) # Berechnung cp Quelle
    msrc = Qsrc / (cpsrc * (Tsrcin-Tsrcout))
        
    #Senke
    psink = inputs.Wert.iloc[11] * Pbc # Druck Senke [Pa]
    dTsinkpinch = inputs.Wert.iloc[14] # Pinchabstand Senke [K]
    mediumsink = inputs.Wert.iloc[10] # Medium Senke
    cpsink = RP.REFPROPdll(mediumsink,"PT","CP",MASS_BASE_SI,0,0,psink,Tsinkin,[1.0]).Output[0]
    msink = (Qsrc*(1-np.abs(thermaleff)))/(cpsink*(Tsinkout-Tsinkin))
    T1011 = Tsinkin + 25 # Kondensationstemperatur (Startwert) --> noch zu iterieren
    p1011 = 2e4
        
    #ORC
    T45 = inputs.Wert.iloc[22]#5 # Dampfüberhitzung [K]
    T110 = inputs.Wert.iloc[23]#3 # Flüssigkeitsunterkühlung [K]
    
    mediumORC = inputs.Wert.iloc[18]
    effturb = inputs.Wert.iloc[21]
    effreku = inputs.Wert.iloc[19] #0.0
    
    print(effturb)
    M = 1 # erreichte Machzahl am engsten Querschnitt, normalerweise 1 außer ggf. NT
        
    if effreku == 0:
        dp89 = 1000
    else:
        dp89 = 2000+5000+5000 # Druckverlust von Turbinenauslass bis Pumpe
            
    dp56 = 1000 # Druckverlust von Verdampfung bis Turbineneingang
        
    #Startwerte
    T2 = Tsinkin + 20 #+273.15 # Startwert Temperatur nach Pumpe
        
    r = RP.REFPROPdll(mediumORC,"TQ","D",MASS_BASE_SI,0,0,Tsrcout,1,[1.0])
    p34 = r.Output[0]
                
    p34 = 0.7*p34 # Startwert Verdampfungsdruck
        
    #Startwerte können mit "alter" Kreislaufrechnung vorbestimmt werden?
        
    Akrit = inputs.Wert.iloc[20]#135  # mm² Startwert
    Akritstopper = 0
    Akritcounter = 0
        
    #Umrechnung auf Quadratmeter
    Akrit = Akrit/1e6
    
    #Zweiter Rechenschritt: Berechnung des Kreislaufs bei Nennbedingungen
    while Akritstopper == 0:
            
            [morc,T0,T2,T34,T5,T6,T8,T9,T1011,p34,p5,p6,p1011,pi,Qcond,Pmech,Pel,thermaleff,Qregenerate,Qprocess,dTsinkpinch] = \
            ORC(Akrit,mediumORC,msrc,Qsrc,Tsrcin,Tsrcout,T2,T45,p34,p1011,T110,effturb,effreku,Tsinkin,cpsink,msink,dTsrcpinch,dTsinkpinch,dp56,dp89,M)
            
            bilanz = np.abs(Qsrc+Pmech-Qcond)
    
            if bilanz < 1000:
                Akritstopper = 1
                Akritcounter += 1
    
    #fehlende Werte nachtragen
    T1 = T0
    T5 = T34+T45
    
    p8 = p1011 + dp89
    p9 = (p1011+p8)/2
    p1 = p34
    p0 = p1011
    
    #Werte in Tabelle eintragen
    
    T = np.array([T0,T1,T2,T34,T34,T5,T6,T8,T9,T1011,T1011])
    p = np.array([p0,p1,p1,p34,p34,p5,p6,p8,p9,p1011,p1011])
    
    S0 = RP.REFPROPdll(mediumORC,"QT","S",MASS_BASE_SI,0,0,0,T0,[1.0]).Output[0]
    S1 = S0
    S2 = RP.REFPROPdll(mediumORC,"PT","S",MASS_BASE_SI,0,0,p34,T2,[1.0]).Output[0]
    S3 = RP.REFPROPdll(mediumORC,"PQ","S",MASS_BASE_SI,0,0,p34,0,[1.0]).Output[0]
    S4 = RP.REFPROPdll(mediumORC,"PQ","S",MASS_BASE_SI,0,0,p34,1,[1.0]).Output[0]
    S5 = RP.REFPROPdll(mediumORC,"PT","S",MASS_BASE_SI,0,0,p34,T5,[1.0]).Output[0]
    S6 = RP.REFPROPdll(mediumORC,"PT","S",MASS_BASE_SI,0,0,p34-dp56,T6,[1.0]).Output[0]
    S8 = RP.REFPROPdll(mediumORC,"PT","S",MASS_BASE_SI,0,0,p8,T8,[1.0]).Output[0]
    S9 = RP.REFPROPdll(mediumORC,"PT","S",MASS_BASE_SI,0,0,p9,T9,[1.0]).Output[0]
    S10 = RP.REFPROPdll(mediumORC,"PQ","S",MASS_BASE_SI,0,0,p1011,1,[1.0]).Output[0]
    S11 = RP.REFPROPdll(mediumORC,"PQ","S",MASS_BASE_SI,0,0,p1011,0,[1.0]).Output[0]
    Snew = np.array([S0,S1,S2,S3,S4,S5,S6,S8,S9,S10,S11])
    
    H0 = RP.REFPROPdll(mediumORC,"QT","H",MASS_BASE_SI,0,0,0,T0,[1.0]).Output[0]
    H1 = H0
    H2 = RP.REFPROPdll(mediumORC,"PT","H",MASS_BASE_SI,0,0,p34,T2,[1.0]).Output[0]
    H3 = RP.REFPROPdll(mediumORC,"PQ","H",MASS_BASE_SI,0,0,p34,0,[1.0]).Output[0]
    H4 = RP.REFPROPdll(mediumORC,"PQ","H",MASS_BASE_SI,0,0,p34,1,[1.0]).Output[0]
    H5 = RP.REFPROPdll(mediumORC,"PT","H",MASS_BASE_SI,0,0,p34,T5,[1.0]).Output[0]
    H6 = RP.REFPROPdll(mediumORC,"PT","H",MASS_BASE_SI,0,0,p34-dp56,T6,[1.0]).Output[0]
    H8 = RP.REFPROPdll(mediumORC,"PT","H",MASS_BASE_SI,0,0,p8,T8,[1.0]).Output[0]
    H9 = RP.REFPROPdll(mediumORC,"PT","H",MASS_BASE_SI,0,0,p9,T9,[1.0]).Output[0]
    H10 = RP.REFPROPdll(mediumORC,"PQ","H",MASS_BASE_SI,0,0,p1011,1,[1.0]).Output[0]
    H11 = RP.REFPROPdll(mediumORC,"PQ","H",MASS_BASE_SI,0,0,p1011,0,[1.0]).Output[0]
    Hnew = np.array([H0,H1,H2,H3,H4,H5,H6,H8,H9,H10,H11])
    
    rhotest = list()
    
    for i in range(len(T)):
        r = RP.REFPROPdll(mediumORC,"TP","D",MASS_BASE_SI,0,0,T[i],p[i],[1.0])
        tmp = r.Output[0]
        rhotest.append(tmp)
        del tmp
     
    rho = np.array(rhotest)

    m = np.array([morc,0,0,0,0,0,0,0,0,0,0])
    A = np.array([Akrit*1e6,0,0,0,0,0,0,0,0,0,0])
    Pmecha = np.array([Pmech,0,0,0,0,0,0,0,0,0,0])
    Pele = np.array([Pel,0,0,0,0,0,0,0,0,0,0])
    
    r = RP.REFPROPdll(mediumORC,"PT","D",MASS_BASE_SI,0,0,np.max(p),np.min(T),[1.0])
    Dmax = r.Output[0]
    r = RP.REFPROPdll(mediumORC,"TQ","D",MASS_BASE_SI,0,0,np.max(T),1,[1.0])
    
    # Pumpe
    Druckerhoehung = p34-p1011
    Volumenstrom = morc/Dmax
    hydraulischeLeistung = Druckerhoehung*Volumenstrom/0.55
    
    Pluefter = inputs.Wert.iloc[25]
    Pnetto = np.abs(Pel+hydraulischeLeistung+Pluefter)/1000
    Pnetto = np.format_float_positional(Pnetto, precision=2)
    
    
    Pblas = np.array([Pluefter,0,0,0,0,0,0,0,0,0,0])
    Pnet = np.array([Pnetto,0,0,0,0,0,0,0,0,0,0])
    PPumpe = np.array([hydraulischeLeistung,0,0,0,0,0,0,0,0,0,0])
    thermaleff = np.format_float_positional(thermaleff*-100, precision=2)
    Pel = np.format_float_positional(Pel/-1000, precision=2)
    
    stationen = np.array(['Pumpe ein','Pumpe aus','Vorwärmung','Flüssiggesättigt','Dampfgesättigt','Überhitzung','Turbine ein','Turbine aus','Enthitzt','Dampfgesättigt','Flüssiggesättigt'])
    
    result = pd.DataFrame({'Beschreibung':stationen,'druck':p,'temperatur':T,'dichte':rho,\
                           'massenstrom':m,'Akrit':A,\
                           'Pmechanisch':Pmecha*-1,'Pelektrisch':Pele*-1,'Pluefter':Pblas,\
                           'Ppumpe':PPumpe,'Pnetto':Pnet})
    result.rename(index={0:'Pumpe ein',1:'Pumpe aus',2:'Verdampfung',3:'Überhitzung',4:'Turbine ein',5:'Turbine aus',6:'Kondensation'})

    try:
        os.chdir(savepath)
        result.to_excel('Kreislauf.xlsx',sheet_name='Kreislauf')
        print("Datei erfolgreich erstellt!")
    except:
        print("Beim Erstellen einer Datei ist ein Problem aufgetreten. Bitte versuche es erneut.")
    
    plt.figure(1)
    plt.plot(Snew,T-Tkc, color = "green")
    plt.scatter(Snew, T-Tkc, s=10, color="black")
    plt.plot([S0,S9],[Tsinkin-Tkc,Tsinkout-Tkc],'bo-')
    plt.plot([S2,S5],[Tsrcout-Tkc,Tsrcin-Tkc],'ro-')
    plt.xlabel('Entropy [kJ/kg]')
    plt.ylabel('Temperature [°C]')
    plt.title('T-S-Diagram')
    plt.legend(['Cycle','Sink','Source'])
    plt.grid(which='major',axis='both')
    plt.savefig('TSDiagrammORCCycle.png', dpi = 300)
    plt.figure(1).clear()

    plt.figure(2)
    plt.plot(Hnew,T-Tkc, color = "green")
    plt.scatter(Hnew, T-Tkc, s=10, color="black")
    plt.plot([H0,H9],[Tsinkin-Tkc,Tsinkout-Tkc],'bo-')
    plt.plot([H2,H5],[Tsrcout-Tkc,Tsrcin-Tkc],'ro-')
    plt.grid(which='major',axis='both')
    plt.title("T-Q Diagram")
    plt.xlabel('Power [kW]')
    plt.ylabel('Temperature [°C]')
    plt.title('T-Q-Diagram')
    plt.legend(['Cycle','Sink','Source'])
    plt.savefig('TQDiagrammORCCycle.png', dpi = 300)
    plt.figure(2).clear()
    
    return Pnetto, Pel, thermaleff, savepath

