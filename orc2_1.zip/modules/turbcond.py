# -*- coding: utf-8 -*-
"""
Created on Fri Mar 19 11:58:10 2021

@author: DEBIEKNJ

Turbcond.py contains operations which iterate regeneration/condensation process
and the turbine process and it is a helper module to ORCfktsRP.py.

turbcond.py relies on ORCfktsRP.py module for helper functions.

In order to operate fully and properly, module requires following to be installed:
- numpy
- os
- REFPROP (API and database)

"""
import os; os.environ['RPPREFIX'] = r'C:/REFPROP'
from ctREFPROP.ctREFPROP import REFPROPFunctionLibrary
RP = REFPROPFunctionLibrary(os.environ['RPPREFIX'])
RP.SETPATHdll(os.environ['RPPREFIX'])
MASS_BASE_SI = RP.GETENUMdll(0, "MASS BASE SI").iEnum
    
from modules.ORCfktsRP import phasechange,cpmean
import numpy as np

def turbcond(T2,p6,T6,S6,p1011,effturb,effreku,mediumORC,morc,Qsrc,Tsinkin,cpsink,msink,dTsinkpinch,dp89,T110):
    """
    Iterates the regeneration/condensation process and the turbine process.
    The condensation is dependend on the turbine process an vice versa.

    Parameters
    ----------
    T2 : float or integer
        Temperature of the ORC Medium after preheating in the recuperator in [K].
    p6 : float or integer
        Pressure at the turbine inlet in [Pa].
    T6 : float or integer
        Temperature at the turbine inlet in [K].
    S6 : float or integer
        Entropy at the turbine inlet in [J/kgK].
    p1011 : float or integer
        Condensation pressure in [Pa].
    effturb : float
        Isentropic turbine efficiency [-].
    effreku : float
        Efficiency of the heat regeration of the recuperator [-].
    mediumORC : string
        Name of the medium (i.e. 'ethylbenzene','methylcyclohexane',...).
    morc : float
        Mass flow of the ORC cycle in [kg/s].
    Qsrc : float or integer
        Thermal power of the heat source in [W].
    Tsinkin : float or integer
        Inlet Temperature of the heat sink in [K].
    cpsink : float
        Heat capacity at constant pressure of the heat sink medium in [J/kgK].
    msink : float
        Mass flow of the heat sink medium in [kg/s].
    dTsinkpinch : float or integer
        Minimum allowable temperature difference between the heat sink and the ORC medium in [K].
    dp89 : float or integer
        Pressure loss due to regeneration/condensation between turbine an condensator in [Pa].
    T1011 : float
        Condensation temperature in [K].

    Returns
    -------
    T0 : float
        Temperature at feed pump in [K].
    T2 : float
        Temperature of liquid after recuperation in [K].
    T8 : float
        Temperature after turbine [K].
    T9 : TYPE
        Temperature of gas after recuperation in [K].
    T1011 : float
        Condensation temperature in [K].
    p1011 : float
        Condensation pressure in [Pa].
    pi : float
        Pressure ratio of the turbine.
    Qcond : float
        Thermal power of the condensation.
    Pmech : float
        Mechanical power delivered by the turbine in [W].
    Pel : float
        Electrical power delivered by the turbine in [W].
    thermaleff : float
        Efficiency of the energy transfer from thermal to electrical energy.
    Qregenerate : float
        Thermal power of the recuperation in [W].
    minpinch : float
        Minimum pinch value

    """
    
    # Werte initialisieren
    counter = 0
    dp = 9e4
    dTcond = 5 # Temperature difference between Tsinkout and condensation temperature
        
    while 1:
        
        T1011 = RP.REFPROPdll(mediumORC,"PQ","T",MASS_BASE_SI,0,0,p1011,1,[1.0]).Output[0]
        
        # Berechnung Turbinenaustrittstemperatur (mit Druckverhältnis und Effizienz)
        H8is = RP.REFPROPdll(mediumORC,"SP","H",MASS_BASE_SI,0,0,S6,p1011+dp89,[1.0]).Output[0]
        #Berechnung der isentropen Enthalpie nach der Turbine   
        H6 = RP.REFPROPdll(mediumORC,"PT","H",MASS_BASE_SI,0,0,p6,T6,[1.0]).Output[0]
        #Berechnung der Enthalpie vor der Turbine
        dH = (H8is - H6)*effturb #Berechnung der durch Turbine entzogenen Enthalpie mit Wirkungsgrad
        H8 = H6+dH # Berechnug der Enthalpie nach der Turbine
        Pmech = morc * dH # Berechnung der entzogenen Leistung
        Pel = Pmech*0.95 # Berechnung der elektrischen Leistung mit Wirkungsgrad
        thermaleff = Pel/Qsrc # Berechnung der elektrischen Effizienz
        T8 = RP.REFPROPdll(mediumORC,"PH","T",MASS_BASE_SI,0,0,p1011+dp89,H8,[1.0]).Output[0]
        
        # Berechnung der Rekuperation
        T9min = RP.REFPROPdll(mediumORC,"PQ","T",MASS_BASE_SI,0,0,p1011+dp89,1,[1.0]).Output[0]
        dT = (T8-T9min)*effreku
        T9 = T8 - dT
        hregenerate = cpmean(p1011+dp89,T8,T9,mediumORC) * dT
        Qregenerate = morc * hregenerate
        H9 = RP.REFPROPdll(mediumORC,"PT","H",MASS_BASE_SI,0,0,p1011+dp89,T9,[1.0]).Output[0]
        
        """
        hpc1 = RP.REFPROPdll(mediumORC,"PT","H",MASS_BASE_SI,0,0,p1011+dp89,T8,[1.0]).Output[0]
        hpc2 = RP.REFPROPdll(mediumORC,"PQ","H",MASS_BASE_SI,0,0,p1011,1,[1.0]).Output[0]
        hpcmax = hpc2-hpc1
        hregenerate = np.abs(hpcmax) * effreku # Berechnung der spezifischen Rekuperation
        Qregenerate = hregenerate * morc # Berechnung der Rekuperationsleistung
        #Berechnung der Eigenschaften nach Rekuperation
        H9 = RP.REFPROPdll(mediumORC,"PT","H",MASS_BASE_SI,0,0,p1011+dp89,T8,[1.0]).Output[0]-hregenerate
        #H9 = CP.PropsSI('H','P',p1011+dp89,'T',T8,mediumORC) - hregenerate
        T9 = RP.REFPROPdll(mediumORC,"PH","T",MASS_BASE_SI,0,0,p1011+dp89/2,H9,[1.0]).Output[0]
        #T9 = CP.PropsSI('T','P',p1011+dp89/2,'H',H9,mediumORC)
        """
        
        """
        Change in iteration strategy: iterate the corresponding condensation pressure so that
        the needed condensation energy Qcond can be dissipated from the sytem. Desired Subcooling Tsc is prescribed.
        """
        # Berechnung Kondensationsleistung
        Qcond = Qsrc + Pmech ## Stimmt das, oder müssen doch Wärmeverluste nach außen berücksichtigt werden?
        hcondtarget = Qcond/morc
        # Unterkühlung
        Tsc = T110
        hsc = cpmean(p1011+dp89,T1011,T1011-Tsc,mediumORC) * Tsc
        #hsc = Qcond/morc - hpc - hcond# - hregenerate
        #Enthitzung
        hpc = cpmean(p1011+dp89,T9,T1011,mediumORC) * (T9-T1011)
        #Kondensation
        hcond = phasechange(p1011,mediumORC)
        hsink = (hpc+hcond+hsc)

        
        # Berechnung der Senkentemperaturen
        Ti = Tsinkin + (morc*hpc)/(msink*cpsink)
        Tii = Ti + (morc*hcond)/(msink*cpsink)
        Tsinkout = Tii + (morc*np.abs(hsc))/(msink*cpsink)

        H0 = H9-hpc-hcond-hsc
        try:
            T0 = RP.REFPROPdll(mediumORC,"PH","T",MASS_BASE_SI,0,0,p1011,H0,[1.0]).Output[0]
        except:
            break
            T0 = 293.15
        
        pi = p6/(p1011+dp89)
        H2 = RP.REFPROPdll(mediumORC,"PT","H",MASS_BASE_SI,0,0,p6,T0,[1.0]).Output[0]+hregenerate
        T2 = RP.REFPROPdll(mediumORC,"PH","T",MASS_BASE_SI,0,0,p6,H2,[1.0]).Output[0]     
        
        minpinch = np.min([T1011-Ti,T1011-Tii,T9-Tsinkout]) #T0-Tsinkin,
        
        if minpinch > dTsinkpinch:
            dTcond = dTcond-1
        elif minpinch < dTsinkpinch:
            dTcond = dTcond+1
            
        pmin = RP.REFPROPdll(mediumORC,"TQ","P",MASS_BASE_SI,0,0,Tsinkout+dTcond,0,[1.0]).Output[0]
        
        if hsink < hcondtarget:
            p1011 = np.max([pmin,p1011 - dp])
            dp = dp*0.66

        if hsink > hcondtarget:
            p1011 = np.max([pmin, p1011 + dp])
            dp = dp * 0.66
            
        if (np.abs(hsink/hcondtarget-1) < 0.1):
            break
        
        counter = counter + 1
        if counter > 12:
            print('Turbcond nicht in 12 Schritten erfolgreich')
            break

    return(T0,T2,T8,T9,T1011,p1011,pi,Qcond,Pmech,Pel,thermaleff,Qregenerate,minpinch)

"""
### TEST
# Beispielcase
#
Akrit = 150/1e6
mediumORC = 'Methylcyclohexane'
msrc = 1
Qsrc = 250e3
Tsrcin = 753
Tsrcout = 473 # eigentlich ungenutzt außer um evtl cp zu berechnen
T2 = 400 # vorwärmung
T45 = 5
pinchmin = 10
M = 1

import os; os.environ['RPPREFIX'] = r'C:/REFPROP'
from ctREFPROP.ctREFPROP import REFPROPFunctionLibrary
RP = REFPROPFunctionLibrary(os.environ['RPPREFIX'])
RP.SETPATHdll(os.environ['RPPREFIX'])
MASS_BASE_SI = RP.GETENUMdll(0, "MASS BASE SI").iEnum

from morcevap import morcevap
[morc,p34,T34,TsrcD,Qph,Qevap,Qsh,Qtotal] = morcevap(Akrit,mediumORC,msrc,Qsrc,Tsrcin,Tsrcout,T2,T45,pinchmin,M)

dp56 = 3e4
T2start = T2 # T2 aus morcevap als Startwert für turbcond
p5 = p34 # überhitzter Dampf mit gleichem Druck wie gesättigter Dampf
T5 = T34+T45 # Überhitzungstemperatur
p6 = p34 - dp56 # Druckverlust Dampf bis Turbinenvolute

DT56 = 1 # Temperaturverlust zwischen Verdampfer und Ringraum vor Düse
T6 = T5-DT56 # Temperatur vor Turbine
r = RP.REFPROPdll(mediumORC,"PT","S",MASS_BASE_SI,0,0,p6,T6,[1.0])
S6 = r.Output[0]  


p1011 = 1e5
effturb = 0.7
effreku = 0.7
Tsinkin = 60+273
cpsink = 4200
msink = 3.5
dTsinkpinch = 10
dp89 = 3e4
mediumORC = 'Methylcyclohexane'


# Aufruf
import time
lauf = 0
start = time.time()
while lauf < 10:
    [T0,T2,T8,T9,T1011,p1011,pi,Qcond,Pmech,Pel,thermaleff,Qregenerate,minpinch] = \
        turbcond(T2,p6,T6,S6,p1011,effturb,effreku,mediumORC,morc,Qsrc,Tsinkin,cpsink,msink,dTsinkpinch,dp89)
    lauf += 1#
end = time.time()
print('Ausführungszeit = '+str((end-start)/10))
"""

